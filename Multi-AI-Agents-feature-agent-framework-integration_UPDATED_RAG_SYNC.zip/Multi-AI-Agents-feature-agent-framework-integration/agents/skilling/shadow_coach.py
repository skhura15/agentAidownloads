"""
Shadow Coach Agent

The "Observer" agent that silently monitors the simulation and provides coaching hints.
This agent has FULL knowledge of the coaching rubric but NEVER interacts with CustomerSim.

Key Principles:
1. Silent observation - only outputs to the sidebar "whisper channel"
2. Rubric-based evaluation - checks against SME-defined checkpoints
3. Helpful, not annoying - intervenes only when necessary
4. Positive reinforcement - acknowledges good behaviors too
"""

import logging
from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime

from core.config_manager import ConfigManager
from core.logging_service import LoggingService
from agents.skilling.simple_llm_client import SimpleLLMClient
from agents.skilling.models import (
    SimulationConfig,
    CoachingRubric,
    CoachingCheckpoint,
    SimulationMessage,
    MessageRole,
    CheckpointStatus,
)


def build_coach_system_prompt(config: SimulationConfig) -> str:
    """Build the system prompt for ShadowCoach from SimulationConfig."""
    rubric = config.coaching_rubric
    
    # Format checkpoints
    checkpoint_list = "\n".join([
        f"  {cp.id}. [{cp.importance.upper()}] {cp.description}"
        f"\n     Trigger phrases: {', '.join(cp.trigger_phrases) if cp.trigger_phrases else 'Use judgment'}"
        f"\n     Hint if missed: {cp.hint_if_missed}"
        for cp in rubric.checkpoints
    ])
    
    mistakes_list = "\n".join([f"  - {m}" for m in rubric.common_mistakes_to_watch])
    positive_list = "\n".join([f"  - {p}" for p in rubric.positive_reinforcement_triggers])
    
    return f"""You are a Shadow Coach observing a training simulation. Your job is to monitor the trainee's performance and provide helpful guidance through a private sidebar channel.

## SCENARIO CONTEXT:
{config.scenario_context}

## PRIMARY SKILL BEING PRACTICED:
{config.primary_skill}

## SUCCESS CRITERIA:
{config.success_summary}

## COACHING RUBRIC - CHECKPOINTS TO EVALUATE:
{checkpoint_list}

## COMMON MISTAKES TO WATCH FOR:
{mistakes_list}

## POSITIVE BEHAVIORS TO REINFORCE:
{positive_list}

## YOUR ROLE:

You are a supportive coach watching through a one-way mirror. The trainee can see your hints in a sidebar, but the customer CANNOT see anything you say. You are invisible to the customer.

## HOW TO RESPOND:

After each exchange (trainee message + customer response), analyze:
1. Did the trainee complete any checkpoints?
2. Did the trainee make a common mistake?
3. Is there an opportunity to provide a helpful nudge?

Then respond with EXACTLY ONE of these formats:

### If no intervention needed:
NONE

### If trainee did something good (positive reinforcement):
PRAISE: [brief acknowledgment - max 1 sentence]

### If trainee missed something or could improve:
HINT: [helpful, specific suggestion - max 2 sentences]

### If trainee made a significant mistake:
WARNING: [gentle correction - max 2 sentences]

### If a checkpoint was completed:
CHECKPOINT: [checkpoint_id] - [brief acknowledgment]

## CRITICAL RULES:

1. **BE SELECTIVE** - Don't provide a hint after every exchange. Only intervene when there's real value to add.

2. **BE SPECIFIC** - Generic advice like "be empathetic" is not helpful. Say exactly what to do.

3. **BE BRIEF** - Trainees are in the middle of a conversation. Keep hints to 1-2 sentences max.

4. **BE ENCOURAGING** - Frame feedback positively. "Try acknowledging their frustration first" not "You forgot to show empathy".

5. **DON'T OVERWHELM** - If multiple things happened, focus on the most important one.

6. **TRACK PROGRESS** - Remember which checkpoints have been completed. Don't repeat praise for the same checkpoint.

7. **TIMING MATTERS** - Sometimes the trainee is building toward something. Give them a turn or two before hinting.

## EXAMPLES:

Good hint: "HINT: The customer mentioned they've been waiting 3 hours - acknowledging that specific frustration could help de-escalate."

Bad hint: "HINT: Try being more empathetic." (too vague)

Good praise: "PRAISE: Great job acknowledging their frustration before explaining the policy!"

Good checkpoint: "CHECKPOINT: 2 - Nice work verifying the account details first."

Remember: You're a supportive mentor, not a critic. Help the trainee succeed."""


class ShadowCoachAgent:
    """
    The Observer - silently monitors simulations and provides coaching feedback.
    
    This agent:
    - Has full knowledge of the coaching rubric
    - Evaluates each exchange against checkpoints
    - Provides hints through a separate "whisper channel"
    - NEVER communicates with CustomerSim
    """
    
    def __init__(
        self,
        config_manager: ConfigManager,
        simulation_config: SimulationConfig,
        logger: Optional[logging.Logger] = None
    ):
        self.config = config_manager
        self.sim_config = simulation_config
        self.logger = logger or LoggingService.get_logger("ShadowCoach")
        self.llm = SimpleLLMClient(config_manager)
        
        # Build system prompt from coaching rubric
        self.system_prompt = build_coach_system_prompt(simulation_config)
        
        # Track checkpoint completion
        self.checkpoint_status: Dict[int, CheckpointStatus] = {
            cp.id: CheckpointStatus(
                checkpoint_id=cp.id,
                description=cp.description,
                completed=False
            )
            for cp in simulation_config.coaching_rubric.checkpoints
        }
        
        # Track coaching history
        self.hints_given: List[Dict[str, Any]] = []
        self.turn_count = 0
        
        # Rate limiting - don't hint too frequently
        self.last_hint_turn = -2  # Allow hint on first turn
        self.min_turns_between_hints = 1  # At least 1 turn gap between hints
        
        self.logger.info("ShadowCoach initialized with rubric")
    
    async def analyze(
        self,
        trainee_message: str,
        customer_response: str,
        full_transcript: Optional[List[Dict[str, str]]] = None
    ) -> Tuple[Optional[str], Optional[str]]:
        """
        Analyze the latest exchange and decide whether to provide feedback.
        
        Args:
            trainee_message: What the trainee said
            customer_response: How the customer responded
            full_transcript: Optional full conversation history
            
        Returns:
            Tuple of (feedback_type, feedback_content) or (None, None) if no intervention
        """
        self.turn_count += 1
        self.logger.info(f"Turn {self.turn_count}: Coach analyzing exchange")
        
        # Build analysis prompt
        analysis_prompt = self._build_analysis_prompt(
            trainee_message, 
            customer_response,
            full_transcript
        )
        
        try:
            # Use SimpleLLMClient for analysis
            response_text = await self.llm.chat(
                system_prompt=self.system_prompt,
                user_message=analysis_prompt,
                temperature=0.3,  # Lower temperature for consistent evaluation
                max_tokens=300
            )
            
            # Parse the response
            feedback_type, feedback_content = self._parse_coach_response(
                response_text.strip()
            )
            
            # Track hints given
            if feedback_type and feedback_type != "NONE":
                self.hints_given.append({
                    "turn": self.turn_count,
                    "type": feedback_type,
                    "content": feedback_content,
                    "trainee_message": trainee_message[:100]
                })
                self.last_hint_turn = self.turn_count
            
            return feedback_type, feedback_content
                
        except Exception as e:
            self.logger.error(f"ShadowCoach analysis failed: {e}", exc_info=True)
            return None, None
    
    def _build_analysis_prompt(
        self,
        trainee_message: str,
        customer_response: str,
        full_transcript: Optional[List[Dict[str, str]]] = None
    ) -> str:
        """Build the prompt for analysis."""
        # Include checkpoint status
        completed = [
            f"  ✓ {cs.checkpoint_id}: {cs.description}" 
            for cs in self.checkpoint_status.values() 
            if cs.completed
        ]
        pending = [
            f"  ○ {cs.checkpoint_id}: {cs.description}"
            for cs in self.checkpoint_status.values()
            if not cs.completed
        ]
        
        checkpoint_summary = "CHECKPOINTS COMPLETED:\n" + (
            "\n".join(completed) if completed else "  None yet"
        ) + "\n\nCHECKPOINTS PENDING:\n" + "\n".join(pending)
        
        # Build context from transcript if provided
        context = ""
        if full_transcript and len(full_transcript) > 2:
            recent = full_transcript[-6:]  # Last 3 exchanges
            context = "RECENT CONTEXT:\n" + "\n".join([
                f"  {msg['role'].upper()}: {msg['content'][:200]}..."
                if len(msg['content']) > 200 else f"  {msg['role'].upper()}: {msg['content']}"
                for msg in recent[:-2]  # Exclude current exchange
            ]) + "\n\n"
        
        return f"""{context}{checkpoint_summary}

---

CURRENT EXCHANGE (Turn {self.turn_count}):

TRAINEE: {trainee_message}

CUSTOMER: {customer_response}

---

Analyze this exchange. Did the trainee complete any checkpoints? Make any mistakes? Is there a helpful hint you should provide?

Remember:
- Only respond if there's real value to add
- It's been {self.turn_count - self.last_hint_turn} turns since your last hint
- Be specific and brief

Your response (NONE, PRAISE:, HINT:, WARNING:, or CHECKPOINT:):"""

    def _parse_coach_response(self, response: str) -> Tuple[Optional[str], Optional[str]]:
        """Parse the coach's response into type and content."""
        response = response.strip()
        
        if response.upper() == "NONE":
            return None, None
        
        # Parse formatted responses
        for prefix in ["CHECKPOINT:", "PRAISE:", "HINT:", "WARNING:"]:
            if response.upper().startswith(prefix):
                content = response[len(prefix):].strip()
                feedback_type = prefix.rstrip(":")
                
                # Handle checkpoint completion
                if feedback_type == "CHECKPOINT":
                    self._mark_checkpoint_complete(content)
                
                return feedback_type, content
        
        # Fallback - treat as hint if format not recognized
        if response:
            self.logger.warning(f"Unexpected coach response format: {response[:50]}")
            return "HINT", response
        
        return None, None
    
    def _mark_checkpoint_complete(self, content: str) -> None:
        """Mark a checkpoint as completed based on coach response."""
        # Try to extract checkpoint ID from content
        try:
            # Format expected: "2 - Nice work..."
            parts = content.split(" - ", 1)
            if parts:
                checkpoint_id = int(parts[0].strip())
                if checkpoint_id in self.checkpoint_status:
                    self.checkpoint_status[checkpoint_id].completed = True
                    self.checkpoint_status[checkpoint_id].completed_at = (
                        datetime.utcnow().isoformat()
                    )
                    self.checkpoint_status[checkpoint_id].turn_completed = self.turn_count
                    self.logger.info(f"Checkpoint {checkpoint_id} marked complete")
        except (ValueError, IndexError) as e:
            self.logger.debug(f"Could not parse checkpoint ID from: {content}")
    
    def get_checkpoint_status_list(self) -> List[CheckpointStatus]:
        """Get list of all checkpoint statuses."""
        return list(self.checkpoint_status.values())
    
    def get_completion_stats(self) -> Dict[str, Any]:
        """Get completion statistics."""
        total = len(self.checkpoint_status)
        completed = sum(1 for cs in self.checkpoint_status.values() if cs.completed)
        
        return {
            "total_checkpoints": total,
            "completed_checkpoints": completed,
            "completion_percentage": (completed / total * 100) if total > 0 else 0,
            "hints_given": len(self.hints_given),
            "turns_elapsed": self.turn_count
        }
    
    async def generate_summary_feedback(
        self,
        full_transcript: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        """
        Generate end-of-session summary feedback.
        
        Args:
            full_transcript: Complete conversation history
            
        Returns:
            Summary feedback with strengths, opportunities, and overall assessment
        """
        stats = self.get_completion_stats()
        
        # Build summary prompt
        summary_prompt = f"""The training simulation has ended. Generate a brief summary for the trainee.

## SESSION STATS:
- Turns: {self.turn_count}
- Checkpoints completed: {stats['completed_checkpoints']}/{stats['total_checkpoints']}
- Hints provided: {stats['hints_given']}

## CHECKPOINTS STATUS:
""" + "\n".join([
            f"{'✓' if cs.completed else '✗'} {cs.description}"
            for cs in self.checkpoint_status.values()
        ]) + f"""

## HINTS GIVEN:
""" + "\n".join([
            f"Turn {h['turn']}: [{h['type']}] {h['content']}"
            for h in self.hints_given
        ]) + """

Generate a brief, encouraging summary with:
1. 2-3 specific STRENGTHS (things they did well)
2. 1-2 specific OPPORTUNITIES (areas for improvement)
3. A 1-sentence overall summary

Format as JSON:
{
  "strengths": ["strength 1", "strength 2"],
  "opportunities": ["opportunity 1"],
  "summary": "Overall summary sentence"
}"""

        try:
            # Use SimpleLLMClient for summary generation
            response_text = await self.llm.chat(
                system_prompt="You are a supportive training coach providing end-of-session feedback. Always respond with valid JSON.",
                user_message=summary_prompt,
                temperature=0.5,
                max_tokens=500
            )
            
            # Parse JSON response
            import json
            try:
                # Clean up response
                text = response_text.strip()
                if text.startswith("```"):
                    lines = text.split("\n")
                    lines = [l for l in lines if not l.strip().startswith("```")]
                    text = "\n".join(lines)
                
                feedback = json.loads(text)
                feedback["stats"] = stats
                return feedback
            except json.JSONDecodeError:
                return {
                    "strengths": ["Completed the simulation"],
                    "opportunities": ["Review the coaching hints for areas to improve"],
                    "summary": "Good effort! Review the feedback for next time.",
                    "stats": stats
                }
                    
        except Exception as e:
            self.logger.error(f"Failed to generate summary: {e}", exc_info=True)
            return {
                "strengths": [],
                "opportunities": [],
                "summary": "Session completed.",
                "stats": stats
            }
    
    def reset(self) -> None:
        """Reset the coach for a new simulation."""
        for cs in self.checkpoint_status.values():
            cs.completed = False
            cs.completed_at = None
            cs.turn_completed = None
        
        self.hints_given = []
        self.turn_count = 0
        self.last_hint_turn = -2
        self.logger.info("ShadowCoach reset for new simulation")
