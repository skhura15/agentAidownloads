"""
Simulation API Routes

REST endpoints for the Contact Center Knowledge-Based Coach.
"""

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional
import logging

from core.config_manager import ConfigManager
from core.logging_service import LoggingService
from api.dependencies import get_config_manager
from agents.skilling import SimulationOrchestrator

logger = LoggingService.get_logger("simulation_api")

router = APIRouter(prefix="/simulation", tags=["Simulation"])

# Global orchestrator instance (initialized on startup)
_orchestrator: Optional[SimulationOrchestrator] = None


def get_orchestrator() -> SimulationOrchestrator:
    """Dependency to get the simulation orchestrator."""
    global _orchestrator
    if _orchestrator is None:
        raise HTTPException(status_code=503, detail="Simulation service not initialized")
    return _orchestrator


def initialize_simulation_service(config_manager: ConfigManager):
    """Initialize the simulation orchestrator (called on startup)."""
    global _orchestrator
    _orchestrator = SimulationOrchestrator(config_manager)
    logger.info("Simulation service initialized")


# =============================================================================
# Request/Response Models
# =============================================================================

class CaseListItem(BaseModel):
    """Summary of a training case"""
    case_id: str
    title: str
    difficulty: str
    primary_skill: str
    estimated_time: int
    tags: List[str]


class StartSessionRequest(BaseModel):
    """Request to start a new simulation session"""
    case_id: str = Field(..., description="Which case to practice")
    trainee_id: Optional[str] = Field(default=None, description="Trainee identifier")


class StartSessionResponse(BaseModel):
    """Response when starting a session"""
    session_id: str
    case_id: str
    title: str
    difficulty: str
    primary_skill: str
    customer_name: str
    opening_message: str
    total_checkpoints: int


class ChatRequest(BaseModel):
    """Send a message in the simulation"""
    message: str = Field(..., description="Trainee's message to customer")


class ChatResponse(BaseModel):
    """Response from a chat turn"""
    customer_response: str
    coach_feedback: Optional[Dict[str, str]] = None
    checkpoint_status: List[Dict[str, Any]]
    session_stats: Dict[str, Any]


class AskCoachRequest(BaseModel):
    """Explicit request for coach help"""
    question: Optional[str] = Field(default=None, description="Specific question")


class AskCoachResponse(BaseModel):
    """Coach's advice"""
    advice: str


class SessionReportResponse(BaseModel):
    """End of session report"""
    session_id: str
    case_title: str
    total_turns: int
    duration_minutes: float
    checkpoints_completed: int
    total_checkpoints: int
    completion_percentage: float
    hints_received: int
    strengths: List[str]
    opportunities: List[str]
    summary_feedback: str


# =============================================================================
# Endpoints
# =============================================================================

@router.get("/cases", response_model=List[CaseListItem])
async def list_cases(
    orchestrator: SimulationOrchestrator = Depends(get_orchestrator)
) -> List[CaseListItem]:
    """
    List all available training cases.
    
    Returns a list of cases that can be used to start a simulation.
    """
    cases = orchestrator.list_available_cases()
    return [CaseListItem(**case) for case in cases]


@router.post("/start", response_model=StartSessionResponse)
async def start_simulation(
    request: StartSessionRequest,
    orchestrator: SimulationOrchestrator = Depends(get_orchestrator)
) -> StartSessionResponse:
    """
    Start a new simulation session.
    
    Loads the specified case, generates the simulation config,
    and returns the customer's opening message.
    """
    try:
        session = await orchestrator.start_session(
            case_id=request.case_id,
            trainee_id=request.trainee_id
        )
        
        return StartSessionResponse(
            session_id=session.session_id,
            case_id=session.case_id,
            title=session.config.title,
            difficulty=session.config.difficulty,
            primary_skill=session.config.primary_skill,
            customer_name=session.config.customer_profile.name,
            opening_message=session.config.customer_profile.opening_message,
            total_checkpoints=session.total_checkpoints
        )
        
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Failed to start simulation: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to start simulation")


@router.post("/{session_id}/chat", response_model=ChatResponse)
async def send_message(
    session_id: str,
    request: ChatRequest,
    orchestrator: SimulationOrchestrator = Depends(get_orchestrator)
) -> ChatResponse:
    """
    Send a message in the simulation.
    
    The message goes to the CustomerSim agent, and the ShadowCoach
    analyzes the exchange to provide optional coaching feedback.
    """
    try:
        result = await orchestrator.process_message(
            session_id=session_id,
            trainee_message=request.message
        )
        
        return ChatResponse(**result)
        
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Failed to process message: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to process message")


@router.post("/{session_id}/ask-coach", response_model=AskCoachResponse)
async def ask_coach(
    session_id: str,
    request: AskCoachRequest,
    orchestrator: SimulationOrchestrator = Depends(get_orchestrator)
) -> AskCoachResponse:
    """
    Explicitly ask the coach for help.
    
    This is the "Ask Coach" button functionality - lets trainees
    request guidance at any point during the simulation.
    """
    try:
        advice = await orchestrator.ask_coach(
            session_id=session_id,
            question=request.question
        )
        
        return AskCoachResponse(advice=advice)
        
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Failed to get coach advice: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Coach unavailable")


@router.post("/{session_id}/end", response_model=SessionReportResponse)
async def end_simulation(
    session_id: str,
    orchestrator: SimulationOrchestrator = Depends(get_orchestrator)
) -> SessionReportResponse:
    """
    End the simulation and get the report card.
    
    Generates a summary of the session including performance metrics,
    strengths, and areas for improvement.
    """
    try:
        report = await orchestrator.end_session(session_id)
        
        return SessionReportResponse(
            session_id=report.session_id,
            case_title=report.case_title,
            total_turns=report.total_turns,
            duration_minutes=report.duration_minutes,
            checkpoints_completed=report.checkpoints_completed,
            total_checkpoints=report.total_checkpoints,
            completion_percentage=report.completion_percentage,
            hints_received=report.hints_received,
            strengths=report.strengths,
            opportunities=report.opportunities,
            summary_feedback=report.summary_feedback
        )
        
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Failed to end simulation: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to generate report")


@router.get("/{session_id}/status")
async def get_session_status(
    session_id: str,
    orchestrator: SimulationOrchestrator = Depends(get_orchestrator)
) -> Dict[str, Any]:
    """
    Get the current status of a simulation session.
    """
    session = orchestrator.get_session(session_id)
    
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    return {
        "session_id": session.session_id,
        "case_id": session.case_id,
        "is_active": session.is_active,
        "turn_count": session.turn_count,
        "checkpoints_completed": session.checkpoints_completed,
        "total_checkpoints": session.total_checkpoints,
        "hints_received": session.hints_received,
        "started_at": session.started_at,
        "ended_at": session.ended_at
    }


@router.delete("/{session_id}")
async def cleanup_session(
    session_id: str,
    orchestrator: SimulationOrchestrator = Depends(get_orchestrator)
) -> Dict[str, str]:
    """
    Clean up a simulation session from memory.
    """
    orchestrator.cleanup_session(session_id)
    return {"status": "cleaned up", "session_id": session_id}
