# uta_knowledge (Skilling POC)

This folder is intentionally kept **in sync** with:
- `data/cases` (Golden Records)
- `data/sim_configs` (SimulationConfig)

If the cases/configs change, regenerate this folder using:
`python scripts/sync_uta_knowledge_from_cases.py`

Then re-ingest into the vector store (Chroma/Cosmos/Azure Search) using:
`python -m examples.uta_ingest_knowledge --clear`
