# Skilling Agent POC Knowledge Base

This knowledge base is generated from **data/cases** (Golden Records) and **data/sim_configs** (SimulationConfig).
It is intended to be ingested into the RAG vector store so the Skilling POC agents retrieve **scenario-specific** SOP steps and rubrics.

Generated at: 2026-02-03T10:12:59Z

## Contents
- `cases_md/` : human-readable case summaries (KB- prefixed)
- `sops/` : SOP documents derived from SME `correct_sop_steps` (SOP- prefixed)
- `raw_cases/` : raw case JSON copies
- `raw_sim_configs/` : raw SimulationConfig JSON copies

## How to regenerate
Run: `python scripts/sync_uta_knowledge_from_cases.py`
