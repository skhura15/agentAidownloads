# Angry Customer Demanding Refund (TICKET-101)

## Scenario Summary
- Ticket ID: TICKET-101
- Customer: Alex Rivera
- Primary Skill: De-escalation
- Difficulty: intermediate
- Tags: refund, angry-customer, policy-enforcement

## Customer Opening Message
I bought a laptop from you guys 45 days ago and it's already broken! The screen just went black. I want my money back RIGHT NOW. This is absolutely ridiculous!

## Background Context
Customer purchased a laptop 45 days ago. Return policy is 30 days. Warranty covers repairs for 1 year. Customer has been a member for 3 years with 12 previous purchases.

## Customer Persona (from SimulationConfig)
- Tone: Hostile initially, but logical underneath
- Knowledge Level: average
- Secret Condition: Will accept warranty repair if agent shows genuine empathy AND offers expedited service

## Learning Objectives (SME)
- Practice de-escalation techniques with hostile customers
- Learn to explain policy limitations empathetically
- Identify alternative solutions when direct requests cannot be met

## Correct SOP Steps (SME)
- Acknowledge the customer's frustration before anything else
- Express empathy for the situation (broken laptop is genuinely frustrating)
- Verify the purchase date and explain the 30-day return window
- Pivot to the warranty option as an alternative solution
- Offer to expedite the repair process
- If customer remains upset, offer escalation to supervisor or partial store credit

## Coaching Rubric Checkpoints
- [1] Acknowledge the customer's frustration before anything else (trigger: None)
- [2] Express empathy for the situation (broken laptop is genuinely frustrating) (trigger: None)
- [3] Verify the purchase date and explain the 30-day return window (trigger: None)
- [4] Pivot to the warranty option as an alternative solution (trigger: None)
- [5] Offer to expedite the repair process (trigger: None)
- [6] If customer remains upset, offer escalation to supervisor or partial store credit (trigger: None)

## Sticky Notes (SME)
- KEY: The customer will calm down if you acknowledge their frustration FIRST. Don't jump to policy!
- HINT: Mentioning warranty repair + expedited service usually works for this scenario
- TRAP: If agent says 'That's not our policy' without empathy, customer will escalate anger
