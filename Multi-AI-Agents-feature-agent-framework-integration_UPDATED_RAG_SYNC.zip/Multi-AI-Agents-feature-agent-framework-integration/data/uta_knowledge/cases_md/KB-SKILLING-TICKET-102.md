# Double Charge on Subscription (TICKET-102)

## Scenario Summary
- Ticket ID: TICKET-102
- Customer: Jordan Chen
- Primary Skill: Problem Resolution
- Difficulty: beginner
- Tags: billing, subscription, refund-eligible

## Customer Opening Message
Hi, I just noticed I was charged twice for my monthly subscription this month. I see two charges of $29.99 on my credit card dated January 15th. Can you help me with this?

## Background Context
Customer has been subscribed for 8 months. This is a legitimate duplicate charge due to a system glitch. Refund is authorized per policy.

## Customer Persona (from SimulationConfig)
- Tone: Calm and reasonable, slightly concerned
- Knowledge Level: average
- Secret Condition: Will be satisfied with just the refund and timeline, but delighted if offered goodwill gesture

## Learning Objectives (SME)
- Practice standard billing dispute resolution
- Learn to verify account information professionally
- Execute straightforward refund process

## Correct SOP Steps (SME)
- Thank the customer for bringing this to attention
- Verify the account using last 4 digits of card or email
- Confirm you can see the duplicate charge in the system
- Apologize for the inconvenience caused by the error
- Process the refund immediately
- Provide timeline for refund to appear (3-5 business days)
- Offer any goodwill gesture (e.g., one week free extension)

## Coaching Rubric Checkpoints
- [1] Thank the customer for bringing this to attention (trigger: None)
- [2] Verify the account using last 4 digits of card or email (trigger: None)
- [3] Confirm you can see the duplicate charge in the system (trigger: None)
- [4] Apologize for the inconvenience caused by the error (trigger: None)
- [5] Process the refund immediately (trigger: None)
- [6] Provide timeline for refund to appear (3-5 business days) (trigger: None)
- [7] Offer any goodwill gesture (e.g., one week free extension) (trigger: None)

## Sticky Notes (SME)
- EASY WIN: This is a straightforward case. Focus on efficiency and warmth.
- TIP: Always verify before discussing account specifics (privacy)
- BONUS: Offering a small goodwill gesture builds loyalty
