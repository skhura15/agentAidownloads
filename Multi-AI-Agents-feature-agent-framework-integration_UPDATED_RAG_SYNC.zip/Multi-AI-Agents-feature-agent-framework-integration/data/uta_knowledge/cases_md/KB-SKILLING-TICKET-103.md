# Software Not Installing - Frustrated Power User (TICKET-103)

## Scenario Summary
- Ticket ID: TICKET-103
- Customer: Dr. Patricia Kowalski
- Primary Skill: Technical Troubleshooting + De-escalation
- Difficulty: advanced
- Tags: technical, installation, power-user, escalation-risk

## Customer Opening Message
I've been trying to install your enterprise software for 3 hours now. I've already tried running as administrator, disabling antivirus, and checking disk space. Error code 0x80070005. I'm an IT director and I know what I'm doing. Don't give me a script - I need real help.

## Background Context
Customer is an IT Director at a Fortune 500 company. This is an enterprise license ($50K/year). Error 0x80070005 is an access permission issue that requires a specific registry fix. Customer has already done basic troubleshooting.

## Customer Persona (from SimulationConfig)
- Tone: Frustrated but professional, expects peer-level technical discussion
- Knowledge Level: expert
- Secret Condition: Will be satisfied if agent demonstrates technical competence and provides the actual fix quickly

## Learning Objectives (SME)
- Learn to adapt communication style for technical users
- Practice skipping basic troubleshooting when customer demonstrates expertise
- Handle high-value enterprise customers appropriately

## Correct SOP Steps (SME)
- Acknowledge the customer's technical expertise immediately
- Thank them for the detailed error code and troubleshooting already done
- Skip basic troubleshooting steps (they've already done them)
- Go directly to the advanced solution for 0x80070005
- Provide the registry fix steps clearly
- Offer to stay on chat while they try the fix
- If fix doesn't work, offer direct escalation to L3 engineering

## Coaching Rubric Checkpoints
- [1] Acknowledge the customer's technical expertise immediately (trigger: None)
- [2] Thank them for the detailed error code and troubleshooting already done (trigger: None)
- [3] Skip basic troubleshooting steps (they've already done them) (trigger: None)
- [4] Go directly to the advanced solution for 0x80070005 (trigger: None)
- [5] Provide the registry fix steps clearly (trigger: None)
- [6] Offer to stay on chat while they try the fix (trigger: None)
- [7] If fix doesn't work, offer direct escalation to L3 engineering (trigger: None)

## Sticky Notes (SME)
- CRITICAL: This customer WILL leave if you read from script. Adapt immediately!
- KEY: Error 0x80070005 fix requires editing HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System
- VALUE: $50K/year enterprise customer - handle with care
- TRAP: Asking 'Have you tried running as administrator?' will immediately lose trust
