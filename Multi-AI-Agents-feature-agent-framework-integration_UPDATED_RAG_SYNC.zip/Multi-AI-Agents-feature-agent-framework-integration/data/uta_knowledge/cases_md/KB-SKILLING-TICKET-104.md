# MFA Invalid Code - Urgent Login Block (TICKET-104)

## Scenario Summary
- Ticket ID: TICKET-104
- Customer: Amina Hassan
- Primary Skill: Probing & Troubleshooting
- Difficulty: intermediate
- Tags: login, mfa, otp, access-blocked

## Customer Opening Message
I’m locked out of my account. The MFA code keeps saying 'invalid' even though I’m typing it right. I have a deadline in 30 minutes — please help.

## Background Context
Customer uses MFA via authenticator app. This issue is caused by device time drift. Policy: never request OTP codes. Customer is anxious but cooperative.

## Customer Persona (from SimulationConfig)
- Tone: Anxious, polite, time-pressured
- Knowledge Level: average
- Secret Condition: Will calm down if agent acknowledges urgency and provides a clear step-by-step plan quickly

## Learning Objectives (SME)
- Collect key diagnostic details without requesting sensitive data
- Guide the customer through safe troubleshooting steps
- Escalate with complete context if unresolved

## Correct SOP Steps (SME)
- Acknowledge urgency and reassure the customer you will help
- Confirm whether MFA is via SMS or authenticator app
- Ask for safe context (device type, browser/app, when it started, exact error text)
- Check and fix time sync (set device time to automatic) then retry once
- If still failing, guide alternate safe options (backup codes if policy allows, resend, different device/browser)
- Escalate to identity team with timestamp, environment details, and steps already tried

## Coaching Rubric Checkpoints
- [1] Acknowledge urgency and reassure the customer you will help (trigger: None)
- [2] Confirm whether MFA is via SMS or authenticator app (trigger: None)
- [3] Ask for safe context (device type, browser/app, when it started, exact error text) (trigger: None)
- [4] Check and fix time sync (set device time to automatic) then retry once (trigger: None)
- [5] If still failing, guide alternate safe options (backup codes, resend, different device/browser) (trigger: None)
- [6] Escalate to identity team with timestamp, environment details, and steps already tried (trigger: None)

## Sticky Notes (SME)
- KEY: Do NOT ask for OTP codes. Collect safe details only.
- HINT: Time drift on device causes authenticator codes to fail.
- TRAP: Saying 'try later' will escalate the customer immediately.
