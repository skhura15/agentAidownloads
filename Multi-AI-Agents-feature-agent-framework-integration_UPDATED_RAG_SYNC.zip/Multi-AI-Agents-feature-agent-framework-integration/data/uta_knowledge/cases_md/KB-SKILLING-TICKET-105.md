# Delivery Delayed Past ETA - Wants Refund (TICKET-105)

## Scenario Summary
- Ticket ID: TICKET-105
- Customer: Ethan Brooks
- Primary Skill: Expectation Setting
- Difficulty: intermediate
- Tags: delivery, tracking, refund-request, sla

## Customer Opening Message
My package was supposed to arrive two days ago. Tracking hasn’t updated and I’m tired of excuses. I want a refund or a replacement — today.

## Background Context
Order is 2 days past ETA but not yet past refund SLA threshold (refund eligible only after 3 business days past SLA). Replacement allowed only if no tracking movement for 48 hours. Customer is frustrated but not abusive.

## Customer Persona (from SimulationConfig)
- Tone: Frustrated, direct, wants action
- Knowledge Level: average
- Secret Condition: Will accept waiting if agent provides a real tracking-based update and commits to a next update time

## Learning Objectives (SME)
- Use data-based updates instead of vague reassurance
- Set expectations clearly (ETA, investigation, next update time)
- Offer policy-aligned options without sounding dismissive

## Correct SOP Steps (SME)
- Apologize and acknowledge frustration about the delay
- Verify order identifier and check last tracking scan event
- Explain what the tracking status means in plain language
- Provide an updated ETA or investigation timeline
- Offer next steps aligned with policy (investigation, replacement if 48h no movement, refund if SLA exceeded)
- Commit to a concrete next update time

## Coaching Rubric Checkpoints
- [1] Apologize and acknowledge frustration about the delay (trigger: None)
- [2] Verify order identifier and check last tracking scan event (trigger: None)
- [3] Explain what the tracking status means in plain language (trigger: None)
- [4] Provide an updated ETA or investigation timeline (trigger: None)
- [5] Offer next steps aligned with policy (investigation, replacement if 48h no movement, refund if SLA exceeded) (trigger: None)
- [6] Commit to a concrete next update time (trigger: None)

## Sticky Notes (SME)
- KEY: Use the tracking last scan as your anchor. No vague reassurance.
- HINT: Replacement only if no movement 48h; refund after SLA + 3 business days.
- TRAP: If you blame the courier, customer escalates.
