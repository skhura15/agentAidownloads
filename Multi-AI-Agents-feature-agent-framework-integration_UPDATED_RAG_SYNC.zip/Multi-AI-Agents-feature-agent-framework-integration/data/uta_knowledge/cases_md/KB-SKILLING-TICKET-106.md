# Cancel Subscription - Too Expensive + Bad Support (TICKET-106)

## Scenario Summary
- Ticket ID: TICKET-106
- Customer: Sofia Alvarez
- Primary Skill: Retention & Professionalism
- Difficulty: beginner
- Tags: cancellation, retention, billing-cycle, confirmation

## Customer Opening Message
Please cancel my subscription. It’s too expensive and your support hasn’t helped me at all.

## Background Context
Customer is eligible for a single retention offer (tenure 7 months). Policy: offer one discount or pause option once; do not pressure. Must confirm effective cancellation date and billing impact and send confirmation.

## Customer Persona (from SimulationConfig)
- Tone: Disappointed, firm but not rude
- Knowledge Level: average
- Secret Condition: Will consider a pause/discount if offered once respectfully; otherwise wants a clean cancellation

## Learning Objectives (SME)
- Respect cancellation intent without sounding defensive
- Offer one retention option once, not repeatedly
- Confirm end date, billing impact, and send confirmation

## Correct SOP Steps (SME)
- Acknowledge request and confirm you can help with cancellation
- Offer one optional question for feedback (non-intrusive)
- Offer one retention option if eligible (pause or discount) without pressure
- Confirm whether cancellation is immediate or end of billing cycle
- Confirm billing impact (no further charges after effective date)
- Send cancellation confirmation and summarize next steps

## Coaching Rubric Checkpoints
- [1] Acknowledge request and confirm you can help with cancellation (trigger: None)
- [2] Offer one optional question for feedback (non-intrusive) (trigger: None)
- [3] Offer one retention option if eligible (pause or discount) without pressure (trigger: None)
- [4] Confirm whether cancellation is immediate or end of billing cycle (trigger: None)
- [5] Confirm billing impact (no further charges after effective date) (trigger: None)
- [6] Send cancellation confirmation and summarize next steps (trigger: None)

## Sticky Notes (SME)
- KEY: Respect the cancellation request; do not pressure.
- HINT: Offer retention once if eligible; then proceed.
- TRAP: Canceling without stating end date/billing impact causes confusion and churn.
