# Service Outage - Demands ETA and Compensation (TICKET-107)

## Scenario Summary
- Ticket ID: TICKET-107
- Customer: Marcus Lee
- Primary Skill: Incident Communication
- Difficulty: advanced
- Tags: outage, b2b, eta, stakeholder-management

## Customer Opening Message
Your platform is down and my entire team is blocked. I need an ETA right now. If you don’t give me answers, I’m escalating and asking for compensation.

## Background Context
Known incident in progress. No confirmed ETA yet. Policy: do not guess ETAs; provide next update time and official status reference. Offer workaround and capture impact for prioritization. Do not share internal system names.

## Customer Persona (from SimulationConfig)
- Tone: High pressure, demanding, business-impact focused
- Knowledge Level: average
- Secret Condition: Will accept no ETA if agent provides reliable cadence, ownership, and a concrete next update time

## Learning Objectives (SME)
- Communicate clearly without speculation during incidents
- Set update cadence and share confirmed facts only
- Handle high-pressure stakeholder communication professionally

## Correct SOP Steps (SME)
- Acknowledge impact and apologize
- Confirm whether incident is known and reference official status channel
- State clearly that ETA is not confirmed (avoid guessing)
- Commit to a next update time and update cadence
- Collect impact details (region, users impacted, critical workflows)
- Offer workaround if available and escalation path for critical customers

## Coaching Rubric Checkpoints
- [1] Acknowledge impact and apologize (trigger: None)
- [2] Confirm whether incident is known and reference official status channel (trigger: None)
- [3] State clearly that ETA is not confirmed (avoid guessing) (trigger: None)
- [4] Commit to a next update time and update cadence (trigger: None)
- [5] Collect impact details (region, users impacted, critical workflows) (trigger: None)
- [6] Offer workaround if available and escalation path for critical customers (trigger: None)

## Sticky Notes (SME)
- CRITICAL: Never guess an ETA. Provide a next update time instead.
- HINT: Capture impact (region/users/workflows) to prioritize escalation.
- TRAP: Mentioning internal system names is not allowed.
