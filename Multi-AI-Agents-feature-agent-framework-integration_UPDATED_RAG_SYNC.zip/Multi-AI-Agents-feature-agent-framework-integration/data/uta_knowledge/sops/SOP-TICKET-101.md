# SOP for TICKET-101 — Angry Customer Demanding Refund

**Primary Skill:** De-escalation  
**Difficulty:** intermediate  
**Estimated Time:** 10 minutes  

## Correct SOP Steps (SME Approved)
- Acknowledge the customer's frustration before anything else
- Express empathy for the situation (broken laptop is genuinely frustrating)
- Verify the purchase date and explain the 30-day return window
- Pivot to the warranty option as an alternative solution
- Offer to expedite the repair process
- If customer remains upset, offer escalation to supervisor or partial store credit

## Common Mistakes to Avoid
- Immediately saying 'no' to the refund without empathy
- Arguing with the customer about the policy
- Not offering any alternative solutions
- Getting defensive when customer is hostile
