# SOP for TICKET-102 — Double Charge on Subscription

**Primary Skill:** Problem Resolution  
**Difficulty:** beginner  
**Estimated Time:** 8 minutes  

## Correct SOP Steps (SME Approved)
- Thank the customer for bringing this to attention
- Verify the account using last 4 digits of card or email
- Confirm you can see the duplicate charge in the system
- Apologize for the inconvenience caused by the error
- Process the refund immediately
- Provide timeline for refund to appear (3-5 business days)
- Offer any goodwill gesture (e.g., one week free extension)

## Common Mistakes to Avoid
- Not verifying the account before discussing details
- Making the customer wait while 'checking with supervisor' for obvious errors
- Forgetting to give refund timeline
- Not apologizing for the company's error
