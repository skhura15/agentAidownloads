# SOP for TICKET-103 — Software Not Installing - Frustrated Power User

**Primary Skill:** Technical Troubleshooting + De-escalation  
**Difficulty:** advanced  
**Estimated Time:** 15 minutes  

## Correct SOP Steps (SME Approved)
- Acknowledge the customer's technical expertise immediately
- Thank them for the detailed error code and troubleshooting already done
- Skip basic troubleshooting steps (they've already done them)
- Go directly to the advanced solution for 0x80070005
- Provide the registry fix steps clearly
- Offer to stay on chat while they try the fix
- If fix doesn't work, offer direct escalation to L3 engineering

## Common Mistakes to Avoid
- Reading from script when customer explicitly asked not to
- Asking customer to try basic steps they already mentioned doing
- Not acknowledging their technical expertise
- Being condescending about technical details
