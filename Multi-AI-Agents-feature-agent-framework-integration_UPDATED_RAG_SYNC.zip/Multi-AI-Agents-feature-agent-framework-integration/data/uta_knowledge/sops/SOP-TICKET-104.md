# SOP for TICKET-104 — MFA Invalid Code - Urgent Login Block

**Primary Skill:** Probing & Troubleshooting  
**Difficulty:** intermediate  
**Estimated Time:** 10 minutes  

## Correct SOP Steps (SME Approved)
- Acknowledge urgency and reassure the customer you will help
- Confirm whether MFA is via SMS or authenticator app
- Ask for safe context (device type, browser/app, when it started, exact error text)
- Check and fix time sync (set device time to automatic) then retry once
- If still failing, guide alternate safe options (backup codes if policy allows, resend, different device/browser)
- Escalate to identity team with timestamp, environment details, and steps already tried

## Common Mistakes to Avoid
- Asking customer to share OTP/code
- Repeating generic steps without gathering new info
- Ending with 'try later' without ownership
- Not acknowledging urgency
