# SOP for TICKET-105 — Delivery Delayed Past ETA - Wants Refund

**Primary Skill:** Expectation Setting  
**Difficulty:** intermediate  
**Estimated Time:** 12 minutes  

## Correct SOP Steps (SME Approved)
- Apologize and acknowledge frustration about the delay
- Verify order identifier and check last tracking scan event
- Explain what the tracking status means in plain language
- Provide an updated ETA or investigation timeline
- Offer next steps aligned with policy (investigation, replacement if 48h no movement, refund if SLA exceeded)
- Commit to a concrete next update time

## Common Mistakes to Avoid
- Saying 'it will arrive soon' without checking tracking
- Blaming the courier instead of taking ownership
- Not giving a timeline for next update
- Offering refund before eligibility
