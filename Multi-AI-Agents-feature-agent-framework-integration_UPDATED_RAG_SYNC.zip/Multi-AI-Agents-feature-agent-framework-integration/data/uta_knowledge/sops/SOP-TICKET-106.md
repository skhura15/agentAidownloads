# SOP for TICKET-106 — Cancel Subscription - Too Expensive + Bad Support

**Primary Skill:** Retention & Professionalism  
**Difficulty:** beginner  
**Estimated Time:** 8 minutes  

## Correct SOP Steps (SME Approved)
- Acknowledge request and confirm you can help with cancellation
- Offer one optional question for feedback (non-intrusive)
- Offer one retention option if eligible (pause or discount) without pressure
- Confirm whether cancellation is immediate or end of billing cycle
- Confirm billing impact (no further charges after effective date)
- Send cancellation confirmation and summarize next steps

## Common Mistakes to Avoid
- Asking 'why?' in an interrogating way
- Pushing multiple retention offers
- Canceling without confirming implications and end date
- Becoming defensive about support complaint
