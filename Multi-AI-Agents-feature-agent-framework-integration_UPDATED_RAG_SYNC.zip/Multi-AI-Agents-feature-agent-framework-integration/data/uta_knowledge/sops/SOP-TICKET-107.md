# SOP for TICKET-107 — Service Outage - Demands ETA and Compensation

**Primary Skill:** Incident Communication  
**Difficulty:** advanced  
**Estimated Time:** 15 minutes  

## Correct SOP Steps (SME Approved)
- Acknowledge impact and apologize
- Confirm whether incident is known and reference official status channel
- State clearly that ETA is not confirmed (avoid guessing)
- Commit to a next update time and update cadence
- Collect impact details (region, users impacted, critical workflows)
- Offer workaround if available and escalation path for critical customers

## Common Mistakes to Avoid
- Guessing an ETA
- Sounding dismissive about business impact
- No commitment to next update time
- Sharing internal system names or unverified details
