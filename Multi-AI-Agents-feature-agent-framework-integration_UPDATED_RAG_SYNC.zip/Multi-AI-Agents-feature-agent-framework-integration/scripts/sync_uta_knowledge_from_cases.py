#!/usr/bin/env python3
"""
Sync data/uta_knowledge with data/cases and data/sim_configs.

What it does:
1) Archives the existing data/uta_knowledge into data/uta_knowledge_ccaas_archive (overwrites archive)
2) Regenerates data/uta_knowledge with:
   - cases_md/ : KB-SKILLING-<TICKET>.md (human readable)
   - sops/     : SOP-<TICKET>.md (SME SOP steps)
   - raw_cases/ and raw_sim_configs/ : raw JSON copies
   - sample_tickets.json : derived tickets list for RAG ingestion

Usage:
  python scripts/sync_uta_knowledge_from_cases.py
"""

import os
import json
import glob
import shutil
import re
import datetime
from pathlib import Path


ROOT = Path(__file__).parent.parent
CASES_DIR = ROOT / "data" / "cases"
CONFIGS_DIR = ROOT / "data" / "sim_configs"
UTA_DIR = ROOT / "data" / "uta_knowledge"
ARCHIVE_DIR = ROOT / "data" / "uta_knowledge_ccaas_archive"


def md_bullets(items):
    return "\n".join([f"- {x}" for x in items])


def main():
    if not CASES_DIR.exists():
        raise SystemExit(f"Missing cases dir: {CASES_DIR}")
    if not CONFIGS_DIR.exists():
        raise SystemExit(f"Missing sim_configs dir: {CONFIGS_DIR}")
    if not UTA_DIR.exists():
        raise SystemExit(f"Missing uta_knowledge dir: {UTA_DIR}")

    case_files = sorted(CASES_DIR.glob("*.json"))
    cfg_files = sorted(CONFIGS_DIR.glob("*.json"))

    # Load case map
    cases_by_tid = {}
    case_path_by_tid = {}
    for f in case_files:
        data = json.loads(f.read_text(encoding="utf-8"))
        tid = data.get("ticket_id")
        if not tid:
            continue
        cases_by_tid[tid] = data
        case_path_by_tid[tid] = f

    # Load config map
    cfg_by_tid = {}
    cfg_path_by_tid = {}
    for f in cfg_files:
        data = json.loads(f.read_text(encoding="utf-8"))
        tid = data.get("case_id")
        if not tid:
            continue
        cfg_by_tid[tid] = data
        cfg_path_by_tid[tid] = f

    # Archive current uta_knowledge
    if ARCHIVE_DIR.exists():
        shutil.rmtree(ARCHIVE_DIR)
    shutil.copytree(UTA_DIR, ARCHIVE_DIR)

    # Clear uta_knowledge (keep folder)
    for item in UTA_DIR.iterdir():
        if item.is_dir():
            shutil.rmtree(item)
        else:
            item.unlink()

    # Create structure
    for sub in ["cases_md", "sops", "raw_cases", "raw_sim_configs"]:
        (UTA_DIR / sub).mkdir(parents=True, exist_ok=True)

    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    (UTA_DIR / "SKILLING_INDEX.md").write_text(
        f"""# Skilling Agent POC Knowledge Base

This knowledge base is generated from **data/cases** (Golden Records) and **data/sim_configs** (SimulationConfig).
It is intended to be ingested into the vector store so the Skilling POC agents retrieve **scenario-specific** SOP steps and rubrics.

Generated at: {now}

## Contents
- `cases_md/` : human-readable case summaries (KB- prefixed)
- `sops/` : SOP documents derived from SME `correct_sop_steps` (SOP- prefixed)
- `raw_cases/` : raw case JSON copies
- `raw_sim_configs/` : raw SimulationConfig JSON copies
""",
        encoding="utf-8",
    )

    tickets = []
    for tid in sorted(cases_by_tid.keys()):
        case = cases_by_tid[tid]
        cfg = cfg_by_tid.get(tid)

        title = case.get("title", tid)
        skill = case.get("primary_skill", "")
        difficulty = case.get("difficulty", "")
        est = case.get("estimated_time_minutes", "")
        tags = case.get("tags", [])
        raw = case.get("raw_content", {})
        cust_name = raw.get("customer_name") or (cfg.get("customer_profile", {}).get("name") if cfg else "Customer")
        initial = raw.get("initial_message", "")
        context = raw.get("context", "")

        annotations = case.get("annotations", {})
        sop_steps = annotations.get("correct_sop_steps", [])
        objectives = annotations.get("learning_objectives", [])
        mistakes = annotations.get("common_mistakes", [])
        sticky = annotations.get("sticky_notes", [])

        # Raw copies
        shutil.copy2(case_path_by_tid[tid], UTA_DIR / "raw_cases" / case_path_by_tid[tid].name)
        if tid in cfg_path_by_tid:
            shutil.copy2(cfg_path_by_tid[tid], UTA_DIR / "raw_sim_configs" / cfg_path_by_tid[tid].name)

        # SOP MD
        (UTA_DIR / "sops" / f"SOP-{tid}.md").write_text(
            f"""# SOP for {tid} — {title}

**Primary Skill:** {skill}  
**Difficulty:** {difficulty}  
**Estimated Time:** {est} minutes  

## Correct SOP Steps (SME Approved)
{md_bullets(sop_steps) if sop_steps else "- (none provided)"}

## Common Mistakes to Avoid
{md_bullets(mistakes) if mistakes else "- (none provided)"}
""",
            encoding="utf-8",
        )

        # Rubric checkpoint strings
        checkpoints = []
        if cfg:
            for cp in cfg.get("coaching_rubric", {}).get("checkpoints", []):
                checkpoints.append(f"[{cp.get('id')}] {cp.get('description')} (trigger: {cp.get('trigger_phrase')})")

        # KB Case MD
        (UTA_DIR / "cases_md" / f"KB-SKILLING-{tid}.md").write_text(
            f"""# {title} ({tid})

## Scenario Summary
- Ticket ID: {tid}
- Customer: {cust_name}
- Primary Skill: {skill}
- Difficulty: {difficulty}
- Tags: {", ".join(tags)}

## Customer Opening Message
{initial}

## Background Context
{context}

## Customer Persona (from SimulationConfig)
- Tone: {cfg.get('customer_profile', {}).get('tone', '') if cfg else case.get('customer_persona_hints', {}).get('tone', '')}
- Knowledge Level: {cfg.get('customer_profile', {}).get('knowledge_level', '') if cfg else ''}
- Secret Condition: {cfg.get('customer_profile', {}).get('secret_condition', '') if cfg else case.get('customer_persona_hints', {}).get('secret_acceptance_condition', '')}

## Learning Objectives (SME)
{md_bullets(objectives) if objectives else "- (none provided)"}

## Correct SOP Steps (SME)
{md_bullets(sop_steps) if sop_steps else "- (none provided)"}

## Coaching Rubric Checkpoints
{md_bullets(checkpoints) if checkpoints else "- (not available yet)"}

## Sticky Notes (SME)
{md_bullets(sticky) if sticky else "- (none provided)"}
""",
            encoding="utf-8",
        )

        # Build ticket entry for sample_tickets.json
        words = re.findall(r"[A-Za-z']{4,}", initial.lower())
        top_words = []
        stop = {"this", "that", "have", "want", "need", "just", "really", "right", "now", "been", "from", "with", "your", "guys"}
        for w in words:
            if w in stop:
                continue
            if w not in top_words:
                top_words.append(w)
            if len(top_words) >= 6:
                break

        expected_signals = list(dict.fromkeys([*tags, *top_words]))[:10]

        tickets.append(
            {
                "id": tid,
                "title": title,
                "description": f"{initial} {context}".strip(),
                "category": skill,
                "expected_signals": expected_signals,
                "priority": "P2" if difficulty in ("beginner", "easy") else ("P1" if difficulty in ("advanced", "hard") else "P3"),
                "expected_checks": [f"SOP-{tid}"],
            }
        )

    (UTA_DIR / "sample_tickets.json").write_text(
        json.dumps(
            {
                "description": "Skilling POC tickets generated from data/cases and data/sim_configs",
                "version": "1.0",
                "generated_at": now,
                "tickets": tickets,
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    (UTA_DIR / "README.md").write_text(
        """# uta_knowledge (Skilling POC)

This folder is intentionally kept **in sync** with:
- `data/cases` (Golden Records)
- `data/sim_configs` (SimulationConfig)

If the cases/configs change, regenerate this folder using:
`python scripts/sync_uta_knowledge_from_cases.py`

Then re-ingest into the vector store (Chroma/Cosmos/Azure Search) using:
`python -m examples.uta_ingest_knowledge --clear`
""",
        encoding="utf-8",
    )

    print(f"✅ Synced {len(tickets)} cases into {UTA_DIR}")
    print(f"📦 Previous uta_knowledge archived to {ARCHIVE_DIR}")


if __name__ == "__main__":
    main()
