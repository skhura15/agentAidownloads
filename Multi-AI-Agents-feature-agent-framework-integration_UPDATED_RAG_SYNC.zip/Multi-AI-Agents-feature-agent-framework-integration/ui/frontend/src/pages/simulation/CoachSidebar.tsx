import { useState } from 'react'
import { CheckpointStatus, CoachFeedback } from '../../services/simulationApi'

interface CoachSidebarProps {
  hints: CoachFeedback[]
  checkpoints: CheckpointStatus[]
  stats: {
    turn_count: number
    checkpoints_completed: number
    total_checkpoints: number
    hints_received: number
    is_active: boolean
  }
  onAskCoach: (question?: string) => void
  onDismissHint: (index: number) => void
}

// Feedback type styling
const feedbackStyles = {
  HINT: {
    bg: 'bg-blue-50 dark:bg-blue-900/30',
    border: 'border-blue-200 dark:border-blue-800',
    icon: '💡',
    title: 'Tip',
    textColor: 'text-blue-800 dark:text-blue-200',
  },
  PRAISE: {
    bg: 'bg-green-50 dark:bg-green-900/30',
    border: 'border-green-200 dark:border-green-800',
    icon: '⭐',
    title: 'Nice!',
    textColor: 'text-green-800 dark:text-green-200',
  },
  WARNING: {
    bg: 'bg-amber-50 dark:bg-amber-900/30',
    border: 'border-amber-200 dark:border-amber-800',
    icon: '⚠️',
    title: 'Watch out',
    textColor: 'text-amber-800 dark:text-amber-200',
  },
  CHECKPOINT: {
    bg: 'bg-purple-50 dark:bg-purple-900/30',
    border: 'border-purple-200 dark:border-purple-800',
    icon: '✅',
    title: 'Checkpoint!',
    textColor: 'text-purple-800 dark:text-purple-200',
  },
}

export default function CoachSidebar({
  hints,
  checkpoints,
  stats,
  onAskCoach,
  onDismissHint,
}: CoachSidebarProps) {
  const [isAskingCoach, setIsAskingCoach] = useState(false)
  const [askQuestion, setAskQuestion] = useState('')

  const handleAskCoach = () => {
    onAskCoach(askQuestion || undefined)
    setAskQuestion('')
    setIsAskingCoach(false)
  }

  const completionPercentage = stats.total_checkpoints > 0
    ? Math.round((stats.checkpoints_completed / stats.total_checkpoints) * 100)
    : 0

  return (
    <div className="w-80 bg-gray-50 dark:bg-gray-850 border-l border-gray-200 dark:border-gray-700 flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-semibold text-gray-900 dark:text-white flex items-center">
            <span className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></span>
            Shadow Coach
          </h2>
          <span className="text-xs text-gray-500 dark:text-gray-400">
            Turn {stats.turn_count}
          </span>
        </div>
        
        {/* Progress Bar */}
        <div className="mt-3">
          <div className="flex justify-between text-xs text-gray-600 dark:text-gray-400 mb-1">
            <span>Progress</span>
            <span>{stats.checkpoints_completed}/{stats.total_checkpoints} checkpoints</span>
          </div>
          <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-green-500 rounded-full transition-all duration-500"
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* Content - Scrollable */}
      <div className="flex-1 overflow-y-auto">
        {/* Live Feedback Cards */}
        <div className="p-4 space-y-3">
          {hints.length === 0 ? (
            <div className="text-center py-8">
              <span className="text-4xl mb-2 block">👀</span>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                I'm watching and ready to help!
              </p>
            </div>
          ) : (
            hints.slice(-5).map((hint, index) => {
              const style = feedbackStyles[hint.type] || feedbackStyles.HINT
              return (
                <div
                  key={index}
                  className={`${style.bg} ${style.border} border rounded-lg p-3 relative animate-fadeIn`}
                >
                  <button
                    onClick={() => onDismissHint(index)}
                    className="absolute top-2 right-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                  <div className="flex items-start space-x-2 pr-6">
                    <span className="text-lg">{style.icon}</span>
                    <div>
                      <p className={`text-xs font-medium ${style.textColor} mb-1`}>
                        {style.title}
                      </p>
                      <p className="text-sm text-gray-700 dark:text-gray-300">
                        {hint.content}
                      </p>
                    </div>
                  </div>
                </div>
              )
            })
          )}
        </div>

        {/* Objectives Checklist */}
        <div className="px-4 pb-4">
          <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 flex items-center">
            <span className="mr-2">📋</span>
            Objectives
          </h3>
          <div className="space-y-2">
            {checkpoints.length === 0 ? (
              <p className="text-xs text-gray-500 dark:text-gray-400 italic">
                Objectives will appear as you progress...
              </p>
            ) : (
              checkpoints.map((cp) => (
                <div
                  key={cp.checkpoint_id}
                  className={`flex items-start space-x-2 text-sm ${
                    cp.completed
                      ? 'text-green-600 dark:text-green-400'
                      : 'text-gray-600 dark:text-gray-400'
                  }`}
                >
                  <span className="mt-0.5">
                    {cp.completed ? (
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    ) : (
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10" strokeWidth="2" />
                      </svg>
                    )}
                  </span>
                  <span className={cp.completed ? 'line-through' : ''}>
                    {cp.description}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Ask Coach Button */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
        {isAskingCoach ? (
          <div className="space-y-2">
            <textarea
              value={askQuestion}
              onChange={(e) => setAskQuestion(e.target.value)}
              placeholder="What do you need help with? (optional)"
              rows={2}
              className="w-full text-sm rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 px-3 py-2 text-gray-900 dark:text-white placeholder-gray-500 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
            <div className="flex space-x-2">
              <button
                onClick={handleAskCoach}
                className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors"
              >
                Get Help
              </button>
              <button
                onClick={() => setIsAskingCoach(false)}
                className="px-3 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white text-sm transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={() => setIsAskingCoach(true)}
            disabled={!stats.is_active}
            className="w-full py-2 px-4 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 disabled:opacity-50 text-white font-medium rounded-lg transition-all flex items-center justify-center space-x-2"
          >
            <span>🙋</span>
            <span>Ask Coach for Help</span>
          </button>
        )}
      </div>
    </div>
  )
}
