import { SessionReport } from '../../services/simulationApi'

interface SessionReportModalProps {
  report: SessionReport
  onClose: () => void
  onTryAgain: () => void
}

export default function SessionReportModal({
  report,
  onClose,
  onTryAgain,
}: SessionReportModalProps) {
  // Determine performance level
  const getPerformanceLevel = () => {
    if (report.completion_percentage >= 80) return { label: 'Excellent', color: 'text-green-600', emoji: '🌟' }
    if (report.completion_percentage >= 60) return { label: 'Good', color: 'text-blue-600', emoji: '👍' }
    if (report.completion_percentage >= 40) return { label: 'Developing', color: 'text-yellow-600', emoji: '📈' }
    return { label: 'Needs Practice', color: 'text-orange-600', emoji: '💪' }
  }

  const performance = getPerformanceLevel()

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-500 to-purple-500 rounded-t-2xl p-6 text-center text-white">
          <span className="text-5xl mb-2 block">{performance.emoji}</span>
          <h2 className="text-2xl font-bold">{performance.label}!</h2>
          <p className="text-blue-100 mt-1">Session Complete</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-4 p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="text-center">
            <p className="text-3xl font-bold text-gray-900 dark:text-white">
              {report.total_turns}
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400">Turns</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-gray-900 dark:text-white">
              {Math.round(report.completion_percentage)}%
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400">Completed</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-gray-900 dark:text-white">
              {report.duration_minutes.toFixed(1)}
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400">Minutes</p>
          </div>
        </div>

        {/* Checkpoint Progress */}
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
              Checkpoints
            </span>
            <span className="text-sm text-gray-500 dark:text-gray-400">
              {report.checkpoints_completed}/{report.total_checkpoints}
            </span>
          </div>
          <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-green-400 to-green-600 rounded-full transition-all duration-500"
              style={{ width: `${report.completion_percentage}%` }}
            />
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
            {report.hints_received} coaching hints received
          </p>
        </div>

        {/* Summary Feedback */}
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
          <p className="text-gray-700 dark:text-gray-300 text-sm italic">
            "{report.summary_feedback}"
          </p>
        </div>

        {/* Strengths */}
        {report.strengths.length > 0 && (
          <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h3 className="font-medium text-gray-900 dark:text-white mb-2 flex items-center">
              <span className="text-green-500 mr-2">✓</span>
              Strengths
            </h3>
            <ul className="space-y-1">
              {report.strengths.map((strength, i) => (
                <li key={i} className="text-sm text-gray-600 dark:text-gray-400 flex items-start">
                  <span className="text-green-500 mr-2">•</span>
                  {strength}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Opportunities */}
        {report.opportunities.length > 0 && (
          <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h3 className="font-medium text-gray-900 dark:text-white mb-2 flex items-center">
              <span className="text-blue-500 mr-2">📈</span>
              Opportunities
            </h3>
            <ul className="space-y-1">
              {report.opportunities.map((opportunity, i) => (
                <li key={i} className="text-sm text-gray-600 dark:text-gray-400 flex items-start">
                  <span className="text-blue-500 mr-2">•</span>
                  {opportunity}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Actions */}
        <div className="p-6 flex space-x-3">
          <button
            onClick={onTryAgain}
            className="flex-1 py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
          >
            Practice Again
          </button>
          <button
            onClick={onClose}
            className="flex-1 py-3 px-4 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 font-medium rounded-lg transition-colors"
          >
            Back to Menu
          </button>
        </div>
      </div>
    </div>
  )
}
