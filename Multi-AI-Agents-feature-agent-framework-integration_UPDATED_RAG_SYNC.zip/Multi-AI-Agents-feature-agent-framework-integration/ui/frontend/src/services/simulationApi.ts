import axios from 'axios'

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000'

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

// =============================================================================
// Types
// =============================================================================

export interface CaseListItem {
  case_id: string
  title: string
  difficulty: 'beginner' | 'intermediate' | 'advanced'
  primary_skill: string
  estimated_time: number
  tags: string[]
}

export interface StartSessionRequest {
  case_id: string
  trainee_id?: string
}

export interface StartSessionResponse {
  session_id: string
  case_id: string
  title: string
  difficulty: string
  primary_skill: string
  customer_name: string
  opening_message: string
  total_checkpoints: number
}

export interface ChatRequest {
  message: string
}

export interface CoachFeedback {
  type: 'HINT' | 'PRAISE' | 'WARNING' | 'CHECKPOINT'
  content: string
}

export interface CheckpointStatus {
  checkpoint_id: number
  description: string
  completed: boolean
  completed_at?: string
  turn_completed?: number
}

export interface SessionStats {
  turn_count: number
  checkpoints_completed: number
  total_checkpoints: number
  hints_received: number
  is_active: boolean
}

export interface ChatResponse {
  customer_response: string
  coach_feedback: CoachFeedback | null
  checkpoint_status: CheckpointStatus[]
  session_stats: SessionStats
}

export interface AskCoachRequest {
  question?: string
}

export interface AskCoachResponse {
  advice: string
}

export interface SessionReport {
  session_id: string
  case_title: string
  total_turns: number
  duration_minutes: number
  checkpoints_completed: number
  total_checkpoints: number
  completion_percentage: number
  hints_received: number
  strengths: string[]
  opportunities: string[]
  summary_feedback: string
}

export interface SessionStatus {
  session_id: string
  case_id: string
  is_active: boolean
  turn_count: number
  checkpoints_completed: number
  total_checkpoints: number
  hints_received: number
  started_at: string
  ended_at: string | null
}

// =============================================================================
// Simulation API Service
// =============================================================================

export const simulationService = {
  /**
   * Get list of available training cases
   */
  async listCases(): Promise<CaseListItem[]> {
    const response = await apiClient.get<CaseListItem[]>('/simulation/cases')
    return response.data
  },

  /**
   * Start a new simulation session
   */
  async startSession(request: StartSessionRequest): Promise<StartSessionResponse> {
    const response = await apiClient.post<StartSessionResponse>('/simulation/start', request)
    return response.data
  },

  /**
   * Send a message in the simulation
   */
  async sendMessage(sessionId: string, message: string): Promise<ChatResponse> {
    const response = await apiClient.post<ChatResponse>(
      `/simulation/${sessionId}/chat`,
      { message }
    )
    return response.data
  },

  /**
   * Explicitly ask the coach for help
   */
  async askCoach(sessionId: string, question?: string): Promise<AskCoachResponse> {
    const response = await apiClient.post<AskCoachResponse>(
      `/simulation/${sessionId}/ask-coach`,
      { question }
    )
    return response.data
  },

  /**
   * End the simulation and get the report
   */
  async endSession(sessionId: string): Promise<SessionReport> {
    const response = await apiClient.post<SessionReport>(`/simulation/${sessionId}/end`)
    return response.data
  },

  /**
   * Get current session status
   */
  async getSessionStatus(sessionId: string): Promise<SessionStatus> {
    const response = await apiClient.get<SessionStatus>(`/simulation/${sessionId}/status`)
    return response.data
  },

  /**
   * Clean up a session
   */
  async cleanupSession(sessionId: string): Promise<void> {
    await apiClient.delete(`/simulation/${sessionId}`)
  },
}

export default simulationService
