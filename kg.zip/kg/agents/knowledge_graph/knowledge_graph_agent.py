# agents/knowledge_graph/knowledge_graph_agent.py
from __future__ import annotations

from typing import Any, Dict, Optional

from agents.base_agent import BaseAgent
from core.knowledge_graph.service import KnowledgeGraphService


class KnowledgeGraphAgent(BaseAgent):
    """
    Knowledge Graph Agent (scaffold).
    In the next iteration, _execute_logic will call LLM to classify query_type + params
    and route to KnowledgeGraphService.
    """

    def __init__(self, config_manager=None, state_manager=None, tenant_id: str = "tenant_demo"):
        super().__init__(config_manager=config_manager, state_manager=state_manager)
        self.tenant_id = tenant_id
        self.kg = KnowledgeGraphService(tenant_id=self.tenant_id)

    async def _load_configuration(self) -> None:
        # Load agent prompt/config later from configs or prompts folder.
        return

    async def _setup_tools(self) -> None:
        # No external tools needed for core graph calls.
        return

    async def _execute_logic(self, query: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        For now: simple direct commands for testing integration.
        Later: LLM classification -> route.
        """
        q = (query or "").lower()
        if "blast radius" in q or "dependencies" in q:
            # naive parse: expecting service_id in query for now
            service_id = context.get("service_id") if context else None
            service_id = service_id or "svc_db_cluster"
            return {"query_type": "blast_radius", "data": self.kg.get_blast_radius(service_id, depth=3)}

        return {"query_type": "graph_overview", "data": {"message": "KnowledgeGraphAgent scaffold ready."}}
