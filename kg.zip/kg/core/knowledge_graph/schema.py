# core/knowledge_graph/schema.py
from __future__ import annotations

import logging
from typing import List

from core.knowledge_graph.db import get_graph_db

logger = logging.getLogger(__name__)


# (Label, unique_key) pairs (per doc: uniqueness constraints for all node types)
# We'll use tenant_id + <business_id> for idempotent merges.
UNIQUE_KEYS = [
    ("Service", "service_id"),
    ("Incident", "incident_id"),
    ("RootCause", "root_cause_id"),
    ("Symptom", "symptom_id"),
    ("Resolution", "resolution_id"),
    ("Runbook", "runbook_id"),
    ("SOP", "sop_id"),
    ("Document", "doc_id"),
    ("Customer", "customer_id"),
    ("Product", "product_id"),
    ("Feature", "feature_id"),
    ("Release", "release_id"),
    ("Engineer", "engineer_id"),
    ("ErrorSignature", "signature_id"),
    ("Deployment", "deployment_id"),
    ("FAQ", "faq_id"),
    ("FeatureFlag", "flag_id"),
    ("CustomerContact", "contact_id"),
    ("Team", "team_id"),
    ("SLAContract", "sla_id"),
]

UNIQUE_KEY_BY_LABEL = {label: key for label, key in UNIQUE_KEYS}
INDEXES = [
    # tenant isolation and speed
    ("Service", ["tenant_id"]),
    ("Incident", ["tenant_id"]),
    ("Customer", ["tenant_id"]),
    ("Product", ["tenant_id"]),
    ("Feature", ["tenant_id"]),
    ("SOP", ["tenant_id"]),
    ("Runbook", ["tenant_id"]),
    ("RootCause", ["tenant_id"]),
    ("Symptom", ["tenant_id"]),
    ("Deployment", ["tenant_id"]),
    ("Release", ["tenant_id"]),
    ("Document", ["tenant_id"]),
    ("Engineer", ["tenant_id"]),
    ("Team", ["tenant_id"]),
    ("FAQ", ["tenant_id"]),
    ("FeatureFlag", ["tenant_id"]),
    ("ErrorSignature", ["tenant_id"]),
    # common search
    ("Service", ["name"]),
    ("Product", ["name"]),
    ("Customer", ["name"]),
    ("Feature", ["name"]),
    ("Incident", ["severity"]),
    ("Incident", ["created_at"]),
    ("RootCause", ["category"]),
    ("SLAContract", ["tenant_id"]),
    ("CustomerContact", ["tenant_id"]),
    ("SOP", ["category"]),
]


def init_graph_db() -> bool:
    """
    Creates constraints and indexes. Must NOT crash the app if Neo4j is unreachable.
    Returns True if initialization succeeded, else False.
    """
    db = get_graph_db()
    if not db.health_check():
        logger.warning("Neo4j unreachable. Knowledge Graph features will be disabled.")
        return False

    # Constraints
    for label, key in UNIQUE_KEYS:
        name = f"uq_{label.lower()}_{key.lower()}_tenant"
        cypher = f"""
        CREATE CONSTRAINT {name} IF NOT EXISTS
        FOR (n:{label})
        REQUIRE (n.tenant_id, n.{key}) IS UNIQUE
        """
        try:
            db.execute_write(cypher)
        except Exception:
            logger.exception("Failed creating constraint %s", name)

    # Indexes
    for label, props in INDEXES:
        idx_name = f"idx_{label.lower()}_{'_'.join([p.lower() for p in props])}"
        props_cypher = ", ".join([f"n.{p}" for p in props])
        cypher = f"""
        CREATE INDEX {idx_name} IF NOT EXISTS
        FOR (n:{label})
        ON ({props_cypher})
        """
        try:
            db.execute_write(cypher)
        except Exception:
            logger.exception("Failed creating index %s", idx_name)

    logger.info("Neo4j schema initialization complete.")
    return True
