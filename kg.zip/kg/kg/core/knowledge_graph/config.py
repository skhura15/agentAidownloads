from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
RAG_ENV_PATH = BASE_DIR / "rag" / ".env"

load_dotenv(RAG_ENV_PATH)


def _get_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "t", "yes", "y", "on"}


@dataclass(frozen=True)
class KnowledgeGraphSettings:
    neo4j_uri: str = os.getenv("NEO4J_URI")
    neo4j_user: str = os.getenv("NEO4J_USERNAME")
    neo4j_password: str = os.getenv("NEO4J_PASSWORD")
    neo4j_database: str = os.getenv("NEO4J_DATABASE", "neo4j")

    knowledge_graph_enabled: bool = _get_bool("KNOWLEDGE_GRAPH_ENABLED", True)
    seed_on_startup: bool = _get_bool("SEED_KNOWLEDGE_GRAPH_ON_STARTUP", False)


def get_kg_settings() -> KnowledgeGraphSettings:
    return KnowledgeGraphSettings()