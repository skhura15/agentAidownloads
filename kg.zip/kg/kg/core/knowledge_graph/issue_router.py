from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from core.knowledge_graph.rag.retriever import HybridRetriever
from core.knowledge_graph.rag.llm_orchestrator import AzureLLMOrchestrator
from core.knowledge_graph.rag.candidate_judge import CandidateJudge


# ----------------------------------------------------------------------
# MODELS
# ----------------------------------------------------------------------

@dataclass
class IssueMatch:
    issue_id: str
    score: float
    service_ids: List[str]
    debug_hits: List[str]


@dataclass
class EntityMatch:
    entity_id: str
    entity_type: str   # "known_issue" | "service" | "product"
    score: float
    debug_hits: List[str]


# ----------------------------------------------------------------------
# CONSTANTS
# ----------------------------------------------------------------------

MIN_RAG_JUDGE_CONFIDENCE = 0.75
MIN_KG_KEYWORD_SCORE = 2.0

KNOWN_ISSUE_COLLECTION = "kg_known_issues"
SERVICE_COLLECTION = "kg_services"
PRODUCT_COLLECTION = "kg_products"

# kept for future, not used right now
DOCS_COLLECTION = "kg_docs"

HINT_KNOWN_ISSUE = "known_issue"
HINT_SERVICE = "service"
HINT_PRODUCT = "product"
HINT_NONE = "none"

SUPPORTED_HINTS = {
    HINT_KNOWN_ISSUE,
    HINT_SERVICE,
    HINT_PRODUCT,
    HINT_NONE,
}


# ----------------------------------------------------------------------
# BASICS
# ----------------------------------------------------------------------

def _project_root_from_here() -> Path:
    return Path(__file__).resolve().parents[2]


def _build_stage_log() -> Dict[str, Any]:
    return {
        "hint": None,
        "resolution_order": [],
        "branch_attempts": [],
        "rag_started": False,
        "rag_candidates_found": 0,
        "rag_match_found": False,
        "kg_started": False,
        "kg_keywords": [],
        "kg_candidates_found": 0,
        "kg_match_found": False,
        "match_source": "none",   # "rag" | "kg" | "none"
        "messages": [],
    }


def _safe_no_match_response(
    query: str,
    stage_info: Dict[str, Any],
    keywords: Optional[List[str]] = None,
) -> Dict[str, Any]:
    return {
        "ok": True,
        "rag_query": query,
        "fallback_used": stage_info.get("kg_started", False),
        "keywords": keywords or [],
        "stage_info": stage_info,
        "candidates": [],
        "related_known_issues": [],
        "selected_issue_id": None,
        "selected_entity_type": None,
        "selected_entity_id": None,
        "selected_context": None,
        "llm_answer": (
            "I could not find a reliable matching known issue from the available RAG collections "
            "or knowledge graph fallback for this query."
        ),
        "llm_context": None,
        "no_match": True,
    }


def _normalize_hint(hint: Optional[str]) -> str:
    if not hint:
        return HINT_NONE

    value = str(hint).strip().lower()
    alias_map = {
        "issue": HINT_KNOWN_ISSUE,
        "knownissue": HINT_KNOWN_ISSUE,
        "known_issue": HINT_KNOWN_ISSUE,
        "service": HINT_SERVICE,
        "svc": HINT_SERVICE,
        "product": HINT_PRODUCT,
        "prod": HINT_PRODUCT,
        "none": HINT_NONE,
        "": HINT_NONE,
    }
    normalized = alias_map.get(value, HINT_NONE)
    return normalized if normalized in SUPPORTED_HINTS else HINT_NONE


def _resolution_order_from_hint(hint: str) -> List[str]:
    if hint == HINT_KNOWN_ISSUE:
        return [HINT_KNOWN_ISSUE, HINT_SERVICE, HINT_PRODUCT]
    if hint == HINT_SERVICE:
        return [HINT_SERVICE, HINT_KNOWN_ISSUE, HINT_PRODUCT]
    if hint == HINT_PRODUCT:
        return [HINT_PRODUCT, HINT_KNOWN_ISSUE, HINT_SERVICE]
    return [HINT_KNOWN_ISSUE, HINT_SERVICE, HINT_PRODUCT]


def _build_local_retriever(collection_name: str) -> HybridRetriever:
    base_dir = _project_root_from_here()
    chroma_dir = base_dir / "chroma_store"

    return HybridRetriever(
        persist_directory=str(chroma_dir),
        collection_name=collection_name,
        top_k=5,
    )


def _save_rag_result_json(payload: Dict[str, Any], file_name: str) -> None:
    base_dir = _project_root_from_here()
    out_dir = base_dir / "rag_debug"
    out_dir.mkdir(parents=True, exist_ok=True)

    out_file = out_dir / file_name
    out_file.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _safe_hybrid_search(
    collection_name: str,
    query: str,
    top_k: int,
    stage_info: Dict[str, Any],
    debug_file_name: str,
) -> List[Dict[str, Any]]:
    try:
        retriever = _build_local_retriever(collection_name)
        rag_results = retriever.hybrid_search(query, top_k=top_k)

        _save_rag_result_json(
            {
                "collection_name": collection_name,
                "query": query,
                "rag_results": rag_results,
            },
            file_name=debug_file_name,
        )

        return rag_results.get("grouped_results", []) or []
    except Exception as e:
        stage_info["messages"].append(
            f"RAG search failed for collection '{collection_name}': {str(e)}"
        )
        return []


def _extract_service_ids_from_known_issue_context(selected_context: Optional[Dict[str, Any]]) -> List[str]:
    if not selected_context:
        return []

    affected = selected_context.get("affected") or {}
    services = affected.get("services") or []

    service_ids: List[str] = []
    for svc in services:
        sid = svc.get("service_id")
        if sid:
            service_ids.append(sid)

    return service_ids


def _is_known_issue_context_usable(selected_context: Optional[Dict[str, Any]]) -> bool:
    """
    A KnownIssue candidate is only usable for downstream LLM flow if:
      - KG returned a context
      - the issue has a document
      - at least one runbook OR one SOP exists
    """
    if not selected_context:
        return False

    issue = selected_context.get("issue") or {}
    linked = selected_context.get("linked") or {}

    if not issue.get("document"):
        return False

    runbooks = linked.get("runbooks") or []
    sops = linked.get("sops") or []

    if not runbooks and not sops:
        return False

    return True


# ----------------------------------------------------------------------
# KEYWORD FALLBACK
# ----------------------------------------------------------------------

def extract_keywords(text: str) -> List[str]:
    keyword_map = {
        "outage": ["outage", "down", "unavailable", "error", "failure", "drop"],
        "latency": ["slow", "delay", "latency", "timeout", "spinning"],
        "routing": ["routing", "queue", "workstream", "assignment", "overflow"],
        "voice": ["voice", "call", "transfer", "warm transfer", "cold transfer", "acs"],
        "chat": ["chat", "widget", "live chat", "web chat", "messaging"],
        "copilot": ["copilot", "suggestion", "draft", "summarization", "summary", "hallucination"],
        "knowledge": ["knowledge", "kb", "article", "documentation"],
        "wfm": ["wfm", "workforce", "forecast", "schedule", "intraday", "staffing"],
        "qm": ["quality", "qm", "scorecard", "evaluation", "rubric", "calibration"],
        "sso": ["sso", "login", "saml", "oauth", "authentication", "identity", "assertion"],
    }

    text_lower = (text or "").lower()
    found = set()

    for cat, terms in keyword_map.items():
        for term in terms:
            if term in text_lower:
                found.add(cat)
                found.add(term)

    stop_words = {
        "the", "a", "an", "is", "are", "was", "were", "in", "on", "at", "to", "for", "of", "with", "and", "or",
        "it", "this", "that", "be", "has", "have", "had", "do", "does", "did", "will", "would",
    }

    for w in text_lower.split():
        cleaned = w.strip(".,!?;:\"'()[]{}").lower()
        if len(cleaned) > 2 and cleaned not in stop_words:
            found.add(cleaned)

    return list(found)


def _keyword_fallback_known_issue_search(kg: Any, message: str, limit: int = 3) -> Dict[str, Any]:
    keywords = extract_keywords(message)
    keywords_l = [k.lower() for k in keywords]

    cypher = """
    MATCH (ki:KnownIssue {tenant_id:$tenant_id})
    OPTIONAL MATCH (svc:Service {tenant_id:$tenant_id})-[:HAS_KNOWN_ISSUE {tenant_id:$tenant_id}]->(ki)
    RETURN ki AS issue, collect(distinct svc.service_id) AS service_ids
    """

    rows = kg.db.execute_read(cypher, {"tenant_id": kg.tenant_id}) or []

    candidates: List[IssueMatch] = []

    def _as_text(v: Any) -> str:
        if v is None:
            return ""
        if isinstance(v, list):
            return " ".join([str(x) for x in v])
        return str(v)

    for r in rows:
        issue = r.get("issue") or {}
        issue_id = (issue.get("issue_id") or "").strip()
        if not issue_id:
            continue

        service_ids = r.get("service_ids") or []

        hay = " ".join([
            _as_text(issue.get("symptoms")),
            _as_text(issue.get("root_cause")),
            _as_text(issue.get("workaround")),
            _as_text(issue.get("title")),
            _as_text(issue.get("description")),
        ]).lower()

        score = 0.0
        hits: List[str] = []

        for k in keywords_l:
            if k in hay:
                score += 1.0
                hits.append(k)

        if issue_id.lower() in message.lower():
            score += 5.0
            hits.append(issue_id.lower())

        if score > 0:
            candidates.append(
                IssueMatch(
                    issue_id=issue_id,
                    score=score,
                    service_ids=service_ids,
                    debug_hits=hits,
                )
            )

    candidates.sort(key=lambda x: x.score, reverse=True)
    top = candidates[:limit]

    selected_issue_id = None
    if top and float(top[0].score) >= MIN_KG_KEYWORD_SCORE:
        selected_issue_id = top[0].issue_id

    return {
        "keywords": keywords,
        "candidates": top,
        "selected_issue_id": selected_issue_id,
    }


# ----------------------------------------------------------------------
# KG HELPERS
# ----------------------------------------------------------------------

def _get_known_issues_for_service(kg: Any, service_id: str) -> List[str]:
    cypher = """
    MATCH (s:Service {tenant_id:$tenant_id, service_id:$service_id})-[:HAS_KNOWN_ISSUE {tenant_id:$tenant_id}]->(ki:KnownIssue {tenant_id:$tenant_id})
    RETURN DISTINCT ki.issue_id AS issue_id
    """
    rows = kg.db.execute_read(
        cypher,
        {"tenant_id": kg.tenant_id, "service_id": service_id},
    ) or []

    issue_ids: List[str] = []
    for row in rows:
        issue_id = row.get("issue_id")
        if issue_id:
            issue_ids.append(issue_id)
    return issue_ids


def _get_product_node(kg: Any, product_value: str) -> Optional[Dict[str, Any]]:
    """
    Accepts either product_id or product name and returns Product node properties.
    """
    cypher = """
    MATCH (p:Product {tenant_id:$tenant_id})
    WHERE p.product_id = $product_value OR toLower(p.name) = toLower($product_value)
    RETURN properties(p) AS product
    LIMIT 1
    """
    rows = kg.db.execute_read(
        cypher,
        {"tenant_id": kg.tenant_id, "product_value": product_value},
    ) or []

    if not rows:
        return None
    return rows[0].get("product")


def _get_services_for_product(kg: Any, product_value: str) -> List[str]:
    """
    Product -> Features -> Services
    Accepts product_id or product name.
    """
    cypher = """
    MATCH (p:Product {tenant_id:$tenant_id})
    WHERE p.product_id = $product_value OR toLower(p.name) = toLower($product_value)
    MATCH (f:Feature {tenant_id:$tenant_id})-[:PART_OF]->(p)
    MATCH (f)-[:POWERED_BY]->(s:Service {tenant_id:$tenant_id})
    RETURN DISTINCT s.service_id AS service_id
    """
    rows = kg.db.execute_read(
        cypher,
        {"tenant_id": kg.tenant_id, "product_value": product_value},
    ) or []

    service_ids: List[str] = []
    for row in rows:
        sid = row.get("service_id")
        if sid:
            service_ids.append(sid)
    return service_ids


# ----------------------------------------------------------------------
# KNOWN ISSUE JUDGE HELPERS
# ----------------------------------------------------------------------

def _evaluate_known_issue_candidates(
    kg: Any,
    query: str,
    candidate_issue_ids: List[str],
    stage_info: Dict[str, Any],
    source_label: str,
) -> Tuple[Optional[str], Optional[Dict[str, Any]], List[Dict[str, Any]]]:
    judge = CandidateJudge()

    deduped_issue_ids: List[str] = []
    seen: Set[str] = set()

    for issue_id in candidate_issue_ids:
        if issue_id and issue_id not in seen:
            deduped_issue_ids.append(issue_id)
            seen.add(issue_id)

    evaluated: List[Dict[str, Any]] = []
    passing_matches: List[Tuple[str, Dict[str, Any], float]] = []

    for issue_id in deduped_issue_ids:
        ctx = kg.get_known_issue_full_context(issue_id)
        if not ctx:
            continue

        verdict = judge.judge(query, issue_id, ctx)
        is_match = verdict.get("match") is True
        confidence = float(verdict.get("confidence", 0) or 0)

        evaluated_row = {
            "issue_id": issue_id,
            "judge_match": is_match,
            "judge_confidence": confidence,
            "judge_reasoning": verdict.get("reason"),
        }
        evaluated.append(evaluated_row)

        if is_match and confidence >= MIN_RAG_JUDGE_CONFIDENCE and _is_known_issue_context_usable(ctx):
            passing_matches.append((issue_id, ctx, confidence))

    if not passing_matches:
        return None, None, evaluated

    # highest-confidence match wins
    passing_matches.sort(key=lambda x: x[2], reverse=True)
    best_issue_id, best_ctx, best_confidence = passing_matches[0]

    stage_info["messages"].append(
        f"{source_label}: best linked known issue {best_issue_id} matched with confidence {best_confidence:.2f}"
    )

    return best_issue_id, best_ctx, evaluated


# ----------------------------------------------------------------------
# RESPONSE BUILDERS
# ----------------------------------------------------------------------

def _build_issue_led_response(
    query: str,
    stage_info: Dict[str, Any],
    candidates: List[Dict[str, Any]],
    selected_issue_id: str,
    selected_context: Dict[str, Any],
    fallback_used: bool,
    keywords: Optional[List[str]] = None,
    selected_entity_type: Optional[str] = None,
    selected_entity_id: Optional[str] = None,
    related_known_issues: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    orchestrator = AzureLLMOrchestrator()

    llm_result = orchestrator.answer_from_known_issue(
        user_query=query,
        selected_issue_id=selected_issue_id,
        selected_context=selected_context,
    )

    return {
        "ok": True,
        "rag_query": query,
        "fallback_used": fallback_used,
        "keywords": keywords or [],
        "stage_info": stage_info,
        "candidates": candidates,
        "related_known_issues": related_known_issues or [],
        "selected_issue_id": selected_issue_id,
        "selected_entity_type": selected_entity_type or HINT_KNOWN_ISSUE,
        "selected_entity_id": selected_entity_id or selected_issue_id,
        "selected_context": selected_context,
        "llm_answer": llm_result["answer"] if llm_result else None,
        "llm_context": llm_result["assembled_context"] if llm_result else None,
        "no_match": False,
    }


# ----------------------------------------------------------------------
# RAG SEARCH HELPERS
# ----------------------------------------------------------------------

def _search_known_issue_rag(
    query: str,
    limit: int,
    stage_info: Dict[str, Any],
) -> List[IssueMatch]:
    grouped_results = _safe_hybrid_search(
        collection_name=KNOWN_ISSUE_COLLECTION,
        query=query,
        top_k=max(3, min(limit * 3, 10)),
        stage_info=stage_info,
        debug_file_name="last_known_issue_rag_result.json",
    )

    out: List[IssueMatch] = []
    for row in grouped_results:
        if row.get("doc_type") != "KnownIssue":
            continue

        entity_id = row.get("entity_id")
        score = float(row.get("best_score", 0.0))
        sources = row.get("sources", []) or []

        if not entity_id:
            continue

        out.append(
            IssueMatch(
                issue_id=entity_id,
                score=score,
                service_ids=[],
                debug_hits=list(sources),
            )
        )

    out.sort(key=lambda x: x.score, reverse=True)
    return out[:limit]


def _search_service_rag(
    query: str,
    limit: int,
    stage_info: Dict[str, Any],
) -> List[EntityMatch]:
    grouped_results = _safe_hybrid_search(
        collection_name=SERVICE_COLLECTION,
        query=query,
        top_k=max(3, min(limit * 3, 10)),
        stage_info=stage_info,
        debug_file_name="last_service_rag_result.json",
    )

    out: List[EntityMatch] = []
    for row in grouped_results:
        if row.get("doc_type") != "Service":
            continue

        entity_id = row.get("entity_id")
        score = float(row.get("best_score", 0.0))
        sources = row.get("sources", []) or []

        if not entity_id:
            continue

        out.append(
            EntityMatch(
                entity_id=entity_id,
                entity_type=HINT_SERVICE,
                score=score,
                debug_hits=list(sources),
            )
        )

    out.sort(key=lambda x: x.score, reverse=True)
    return out[:limit]


def _search_product_rag(
    query: str,
    limit: int,
    stage_info: Dict[str, Any],
) -> List[EntityMatch]:
    grouped_results = _safe_hybrid_search(
        collection_name=PRODUCT_COLLECTION,
        query=query,
        top_k=max(3, min(limit * 3, 10)),
        stage_info=stage_info,
        debug_file_name="last_product_rag_result.json",
    )

    out: List[EntityMatch] = []
    for row in grouped_results:
        if row.get("doc_type") != "Product":
            continue

        entity_id = row.get("entity_id")
        score = float(row.get("best_score", 0.0))
        sources = row.get("sources", []) or []

        if not entity_id:
            continue

        out.append(
            EntityMatch(
                entity_id=entity_id,
                entity_type=HINT_PRODUCT,
                score=score,
                debug_hits=list(sources),
            )
        )

    out.sort(key=lambda x: x.score, reverse=True)
    return out[:limit]


# ----------------------------------------------------------------------
# BRANCH RESOLVERS
# ----------------------------------------------------------------------

def _resolve_known_issue_branch(
    kg: Any,
    query: str,
    limit: int,
    stage_info: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    stage_info["rag_started"] = True
    stage_info["branch_attempts"].append(HINT_KNOWN_ISSUE)
    stage_info["messages"].append("Known issue RAG search started")

    rag_top = _search_known_issue_rag(query, limit, stage_info)
    stage_info["rag_candidates_found"] += len(rag_top)
    stage_info["messages"].append(f"Known issue RAG found {len(rag_top)} candidate(s)")

    if not rag_top:
        return None

    selected_issue_id, selected_context, evaluated = _evaluate_known_issue_candidates(
        kg=kg,
        query=query,
        candidate_issue_ids=[c.issue_id for c in rag_top],
        stage_info=stage_info,
        source_label="KnownIssue branch",
    )

    if not selected_issue_id or not selected_context:
        return None

    stage_info["rag_match_found"] = True
    stage_info["match_source"] = "rag"

    rag_candidates = [asdict(c) for c in rag_top]
    for candidate in rag_candidates:
        if candidate["issue_id"] == selected_issue_id:
            candidate["service_ids"] = _extract_service_ids_from_known_issue_context(selected_context)

    return _build_issue_led_response(
        query=query,
        stage_info=stage_info,
        candidates=rag_candidates,
        selected_issue_id=selected_issue_id,
        selected_context=selected_context,
        fallback_used=False,
        keywords=[],
        selected_entity_type=HINT_KNOWN_ISSUE,
        selected_entity_id=selected_issue_id,
        related_known_issues=evaluated,
    )


def _resolve_service_branch(
    kg: Any,
    query: str,
    limit: int,
    stage_info: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    stage_info["rag_started"] = True
    stage_info["branch_attempts"].append(HINT_SERVICE)
    stage_info["messages"].append("Service RAG search started")

    rag_top = _search_service_rag(query, limit, stage_info)
    stage_info["rag_candidates_found"] += len(rag_top)
    stage_info["messages"].append(f"Service RAG found {len(rag_top)} candidate(s)")

    if not rag_top:
        return None

    candidate_payload = [asdict(c) for c in rag_top]

    for candidate in rag_top:
        service_id = candidate.entity_id

        issue_ids = _get_known_issues_for_service(kg, service_id)
        stage_info["messages"].append(
            f"Service {service_id} surfaced {len(issue_ids)} linked known issue candidate(s)"
        )

        selected_issue_id, selected_issue_ctx, evaluated = _evaluate_known_issue_candidates(
            kg=kg,
            query=query,
            candidate_issue_ids=issue_ids,
            stage_info=stage_info,
            source_label=f"Service {service_id}",
        )

        if selected_issue_id and selected_issue_ctx:
            stage_info["rag_match_found"] = True
            stage_info["match_source"] = "rag"

            for row in candidate_payload:
                if row["entity_id"] == service_id:
                    row["linked_known_issue_count"] = len(issue_ids)
                    row["selected_linked_issue_id"] = selected_issue_id

            return _build_issue_led_response(
                query=query,
                stage_info=stage_info,
                candidates=candidate_payload,
                selected_issue_id=selected_issue_id,
                selected_context=selected_issue_ctx,
                fallback_used=False,
                keywords=[],
                selected_entity_type=HINT_SERVICE,
                selected_entity_id=service_id,
                related_known_issues=evaluated,
            )

    return None


def _resolve_product_branch(
    kg: Any,
    query: str,
    limit: int,
    stage_info: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    stage_info["rag_started"] = True
    stage_info["branch_attempts"].append(HINT_PRODUCT)
    stage_info["messages"].append("Product RAG search started")

    rag_top = _search_product_rag(query, limit, stage_info)
    stage_info["rag_candidates_found"] += len(rag_top)
    stage_info["messages"].append(f"Product RAG found {len(rag_top)} candidate(s)")

    if not rag_top:
        return None

    candidate_payload = [asdict(c) for c in rag_top]

    for candidate in rag_top:
        product_value = candidate.entity_id

        product_node = _get_product_node(kg, product_value)
        service_ids = _get_services_for_product(kg, product_value)

        stage_info["messages"].append(
            f"Product {product_value} surfaced {len(service_ids)} related service(s)"
        )

        issue_ids: List[str] = []
        seen_issue_ids: Set[str] = set()

        for service_id in service_ids:
            service_issue_ids = _get_known_issues_for_service(kg, service_id)
            for issue_id in service_issue_ids:
                if issue_id not in seen_issue_ids:
                    issue_ids.append(issue_id)
                    seen_issue_ids.add(issue_id)

        stage_info["messages"].append(
            f"Product {product_value} surfaced {len(issue_ids)} linked known issue candidate(s)"
        )

        selected_issue_id, selected_issue_ctx, evaluated = _evaluate_known_issue_candidates(
            kg=kg,
            query=query,
            candidate_issue_ids=issue_ids,
            stage_info=stage_info,
            source_label=f"Product {product_value}",
        )

        if selected_issue_id and selected_issue_ctx:
            stage_info["rag_match_found"] = True
            stage_info["match_source"] = "rag"

            for row in candidate_payload:
                if row["entity_id"] == product_value:
                    row["product_name"] = (product_node or {}).get("name")
                    row["service_ids"] = service_ids
                    row["linked_known_issue_count"] = len(issue_ids)
                    row["selected_linked_issue_id"] = selected_issue_id

            return _build_issue_led_response(
                query=query,
                stage_info=stage_info,
                candidates=candidate_payload,
                selected_issue_id=selected_issue_id,
                selected_context=selected_issue_ctx,
                fallback_used=False,
                keywords=[],
                selected_entity_type=HINT_PRODUCT,
                selected_entity_id=product_value,
                related_known_issues=evaluated,
            )

    return None


# ----------------------------------------------------------------------
# FINAL KG FALLBACK
# ----------------------------------------------------------------------

def _resolve_kg_keyword_fallback(
    kg: Any,
    query: str,
    limit: int,
    stage_info: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    stage_info["kg_started"] = True
    stage_info["messages"].append("No reliable RAG-led match. KG keyword fallback started")

    fallback = _keyword_fallback_known_issue_search(kg, query, limit)
    keywords = fallback.get("keywords", []) or []
    kg_candidates = fallback.get("candidates", []) or []

    stage_info["kg_keywords"] = keywords
    stage_info["kg_candidates_found"] = len(kg_candidates)
    stage_info["messages"].append(
        f"KG extracted keywords: {', '.join(keywords) if keywords else 'none'}"
    )
    stage_info["messages"].append(f"KG found {len(kg_candidates)} keyword candidate(s)")

    selected_issue_id = fallback.get("selected_issue_id")
    if not selected_issue_id:
        return None

    ctx = kg.get_known_issue_full_context(selected_issue_id)
    if not ctx or not _is_known_issue_context_usable(ctx):
        return None

    stage_info["kg_match_found"] = True
    stage_info["match_source"] = "kg"
    stage_info["messages"].append(f"KG selected {selected_issue_id}")

    candidate_payload = [asdict(c) for c in kg_candidates]
    for candidate in candidate_payload:
        if candidate["issue_id"] == selected_issue_id:
            candidate["service_ids"] = _extract_service_ids_from_known_issue_context(ctx)

    return _build_issue_led_response(
        query=query,
        stage_info=stage_info,
        candidates=candidate_payload,
        selected_issue_id=selected_issue_id,
        selected_context=ctx,
        fallback_used=True,
        keywords=keywords,
        selected_entity_type=HINT_KNOWN_ISSUE,
        selected_entity_id=selected_issue_id,
        related_known_issues=[],
    )


# ----------------------------------------------------------------------
# PUBLIC ENTRYPOINTS
# ----------------------------------------------------------------------

def resolve_issue_from_text(
    kg: Any,
    message: str,
    hint: Optional[str] = None,
    limit: int = 3,
) -> Dict[str, Any]:
    """
    Generic resolver.

    Active flow:
    - KnownIssue RAG -> direct candidate judge
    - Service RAG -> service -> linked known issues -> candidate judge
    - Product RAG -> product -> services -> linked known issues -> candidate judge
    - KG keyword fallback at the end

    Docs RAG is intentionally kept out of active routing for now.
    """
    query = (message or "").strip()
    stage_info = _build_stage_log()

    if not query:
        return {
            "ok": False,
            "rag_query": query,
            "fallback_used": False,
            "keywords": [],
            "stage_info": stage_info,
            "candidates": [],
            "related_known_issues": [],
            "selected_issue_id": None,
            "selected_entity_type": None,
            "selected_entity_id": None,
            "selected_context": None,
            "llm_answer": None,
            "llm_context": None,
            "error": "Empty message",
        }

    normalized_hint = _normalize_hint(hint)
    order = _resolution_order_from_hint(normalized_hint)

    stage_info["hint"] = normalized_hint
    stage_info["resolution_order"] = order
    stage_info["messages"].append(f"Resolution order: {', '.join(order)}")

    branch_map = {
        HINT_KNOWN_ISSUE: _resolve_known_issue_branch,
        HINT_SERVICE: _resolve_service_branch,
        HINT_PRODUCT: _resolve_product_branch,
    }

    for branch_name in order:
        resolver = branch_map.get(branch_name)
        if not resolver:
            continue

        result = resolver(kg, query, limit, stage_info)
        if result:
            return result

    fallback_result = _resolve_kg_keyword_fallback(kg, query, limit, stage_info)
    if fallback_result:
        return fallback_result

    return _safe_no_match_response(
        query=query,
        stage_info=stage_info,
        keywords=stage_info.get("kg_keywords", []),
    )


def resolve_known_issue_from_text(kg: Any, message: str, limit: int = 3) -> Dict[str, Any]:
    return resolve_issue_from_text(
        kg=kg,
        message=message,
        hint=HINT_KNOWN_ISSUE,
        limit=limit,
    )


def resolve_service_from_text(kg: Any, message: str, limit: int = 3) -> Dict[str, Any]:
    return resolve_issue_from_text(
        kg=kg,
        message=message,
        hint=HINT_SERVICE,
        limit=limit,
    )


def resolve_product_from_text(kg: Any, message: str, limit: int = 3) -> Dict[str, Any]:
    return resolve_issue_from_text(
        kg=kg,
        message=message,
        hint=HINT_PRODUCT,
        limit=limit,
    )