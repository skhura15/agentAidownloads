from collections import defaultdict
from pathlib import Path
from typing import Dict, List

from document_loader import DocumentLoader, DocumentChunker, DocumentChunk, get_rag_bucket_for_doc_type
from local_embedder import LocalEmbedder
from chroma_indexer import ChromaIndexer


BASE_DIR = Path(__file__).resolve().parents[3]
DATA_DIR = BASE_DIR / "data" / "kg_docs"
CHROMA_DIR = BASE_DIR / "chroma_store"

COLLECTION_BY_BUCKET = {
    "known_issues": "kg_known_issues",
    "services": "kg_services",
    "products": "kg_products",
    "docs": "kg_docs",  # kept for future use
}


def _group_chunks_by_bucket(chunks: List[DocumentChunk]) -> Dict[str, List[DocumentChunk]]:
    grouped: Dict[str, List[DocumentChunk]] = defaultdict(list)

    for chunk in chunks:
        raw_doc_type = chunk.doc_type
        bucket = "docs"

        if raw_doc_type == "KnownIssue":
            bucket = "known_issues"
        elif raw_doc_type == "Service":
            bucket = "services"
        elif raw_doc_type == "Product":
            bucket = "products"

        grouped[bucket].append(chunk)

    return grouped


def _index_bucket(bucket: str, chunks: List[DocumentChunk], embedder: LocalEmbedder) -> None:
    collection_name = COLLECTION_BY_BUCKET[bucket]

    print(f"\n--- Indexing bucket: {bucket} -> {collection_name} ---")
    print(f"Chunks in bucket: {len(chunks)}")

    indexer = ChromaIndexer(
        persist_directory=str(CHROMA_DIR),
        collection_name=collection_name,
    )

    indexer.reset_collection()

    if not chunks:
        print("No chunks found for this bucket. Collection reset and left empty.")
        return

    embedded_chunks = embedder.embed_chunks(chunks)
    print(f"Generated embeddings for {len(embedded_chunks)} chunks")

    indexer.add_documents(embedded_chunks)
    print(f"Chroma collection count: {indexer.count()}")

    sample = indexer.peek(limit=2)
    print("Sample Chroma peek:")
    print(sample)


def main():
    loader = DocumentLoader()
    chunker = DocumentChunker()
    embedder = LocalEmbedder()

    print("Loading documents...")
    docs = loader.load_directory(str(DATA_DIR))
    print(f"Loaded {len(docs)} documents")

    if docs:
        print("\nSample loaded document metadata:")
        print(docs[0].metadata)

    print("\nChunking documents...")
    chunks = chunker.chunk_documents(docs)
    print(f"Created {len(chunks)} chunks")

    if not chunks:
        raise ValueError(f"No chunks created. Check {DATA_DIR}")

    grouped_chunks = _group_chunks_by_bucket(chunks)

    print("\nBucket counts:")
    for bucket_name in ["known_issues", "services", "products", "docs"]:
        print(f"- {bucket_name}: {len(grouped_chunks.get(bucket_name, []))}")

    for bucket_name in ["known_issues", "services", "products", "docs"]:
        _index_bucket(bucket_name, grouped_chunks.get(bucket_name, []), embedder)

    print("\nIngestion complete.")


if __name__ == "__main__":
    main()